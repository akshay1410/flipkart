package com.demoDomain.teamcity.demoPlugin;

public class AppServer {
}