#!/bin/bash
#set -x
# your server name goes here
server=$1
# the name of the  service account goes here
name=$2
#your namespace name goes here
namespace=$3
mkdir -p ~/.kube

# Validate the script's Arguments
if [[ $# -lt 4 ]] ; then
    echo "usage:  {Server: servername } {svcaccountname: namespace service account} {namespace: projectnamespace} "
    exit 1
fi

#name=$(kubectl get sa -n $namespace $2 -o jsonpath='{.secrets[0].name}')

cluster=$(echo "${server}" |awk -F: '{print$2}' |  awk -F. '{print$1}' | sed 's/\///g')
#ca=$(kubectl get secret/$name -o jsonpath='{.data.ca\.crt}')
ca=Ci0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLQpNSUlDK3pDQ0FlT2dBd0lCQWdJVWZHZ1pCRDArWFV6NVcwK0hTbU1hcEhlZ2llWXdEUVlKS29aSWh2Y05BUUVMCkJRQXdEVEVMTUFrR0ExVUVBeE1DWTJFd0hoY05NVGt3T1RFek1UWXdNREF5V2hjTk1qTXdPVEV6TVRZd01EQXkKV2pBTk1Rc3dDUVlEVlFRREV3SmpZVENDQVNJd0RRWUpLb1pJaHZjTkFRRUJCUUFEZ2dFUEFEQ0NBUW9DZ2dFQgpBTFJoTHJCZ1BaRkJLTy9nd3FISFd5cmNPMGoySUxiVWFsSStSY2pLa2crQXNQRmtiRWxDakNZMHVuRTlCbW9TCmUzeGhoYWFnbUV5cVY1OTgwM2NncFNKM3RjUDhTV0ZJaXV3WDdxM1o4dlFLT1d3VGtFdDNsTlR6Smx4Qkp6WlMKbkVvaHAvWHI5bUlESnRtWm1TRDZJTzc0NStjbTVReHRCRzhhVFNWd1poYWtmQzZaWkJuMVB5TTZQQnhUSTJyNApNY09kOW54RXNWelJyZHNMV1dzU0pnckNTeVBaTkx0TUtqdW83VFFkOVcrNFBLZDRhRnpuZUtWSml3VmV2QWlECk9SbTV5Uk5BSUpVKzlRVmJtTGRqMmN1bTlyUjAwVzZ1blBrMHpRa0RwRkZpYVR1U2s5U2pDdWtKeEZuclc2K3oKWjY0cGZEbE5HSElRZTRpRGtid1lHQThDQXdFQUFhTlRNRkV3SFFZRFZSME9CQllFRk5wRDhaK3psM284bXdKdwo1UlkybjJtek52L3JNQjhHQTFVZEl3UVlNQmFBRk5wRDhaK3psM284bXdKdzVSWTJuMm16TnYvck1BOEdBMVVkCkV3RUIvd1FGTUFNQkFmOHdEUVlKS29aSWh2Y05BUUVMQlFBRGdnRUJBSjFVYjFUTHEzQnhQSmxsQTZIelNudk0KdkE1Nk1xWHphVGpSV3RGS2IySjRHczlNMFFXTVFDdzFnRmFQVFY4Q0xaUE0vSVdBSU9kdVlQVklWUUUrdm9jSgpRcm5vYllSU0l6bC9HMDlucUxlblJ0dUtOYUd4Wk9UWFFHckdYWGFwVE5VK25EL0pRS3IremZMTFZSekxNc2RPClhydldvU0VLRDNkalhWZURteVYwQ3dIbEhZT2JOaDBKakFXY05mS2ZDckhSZzlXVEpXUThpMW05b3hDR3RNTzUKYThLZjdzclRXaE8zRFJjT2NuSDJRV0dIT1EzamVscld5NHNxa1dhZkZNUlpmN2tpZGdHaTVsSCtDZ1RoeVJGbwpMc1diVkhOSWMxcUZEM1gyeTlVanNQU2VGdUwzYyszRlJvdEJrbXZwa2pxdjNGZ2t2aGVMZ29Uckp5aVRtdVk9Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K
#token=$(kubectl get secret/$name -o jsonpath='{.data.token}' | base64 --decode)
token=$4
#namespace=$(kubectl get secret/$name -o jsonpath='{.data.namespace}' | base64 --decode)
#name=kubectl get sa -n $namespace $2 -o jsonpath='{.secrets[0].name}'

#config file genration
echo "
apiVersion: v1
kind: Config
clusters:
- name: ${cluster}
  cluster:
    certificate-authority-data: ${ca}
    server: ${server}
contexts:
- name: ${cluster}
  context:
    cluster: ${cluster}
    namespace: ${namespace}
    user: ${name}
current-context: ${cluster}
users:
- name: ${name}
  user:
    token: ${token}
" > ~/.kube/config
<<<<<<< HEAD
<<<<<<< HEAD

#checks for correct config file
configfile=`cat ~/.kube/config | grep current-context | awk -F: '{print $2}'`

configcmd=`kubectl config view`
flag=$?

if [ "$flag" == "0" ];
then
    if [ "$configout" == "$configfile" ];
    then
       echo "Your context has been switched to $configout successfully"
    fi         
else
   echo "The provided values are incorrect ,please check the values and try again"
   exit 1
fi



=======
>>>>>>> 72b767137921e1b062223b486bf9f9f2743f9c92
=======

#checks for correct config file
    configfile=$(cat ~/.kube/config | grep current-context | awk -F: '{print $2}' | xargs)

    configcmd=$(kubectl config current-context)
    flag=$?

    if [ "$flag" == "0" ];
    then
        if [ "$configcmd" == "$configfile" ];
        then
        echo "Your context has been switched to $configcmd successfully"
        fi         
    else
    echo "The provided values are incorrect ,please check the values and try again"
    exit 1
    fi
>>>>>>> 75e1addc723df84e93675fa009013337499e2810
