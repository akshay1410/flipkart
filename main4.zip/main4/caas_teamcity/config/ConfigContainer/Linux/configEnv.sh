#! /bin/sh

CURRENT_DIR="./"
BUILD_TOOLS="/opt/buildtools/"
ARTI_REPO_URL="https://artifactory.server.rbsgrp.net/artifactory/eetools-buildtools-local/"

getAllBinaries() {
	curl -s $ARTI_REPO_URL/Linux/kubectl.tar -o $CURRENT_DIR/kubectl.tar -k
	curl -s $ARTI_REPO_URL/Linux/tcagent-git-configmap.yaml -o $CURRENT_DIR/tcagent-git-configmap.yaml  -k 
	curl -s $ARTI_REPO_URL/Linux/tcagent-keys-configmap.yaml -o $CURRENT_DIR/tcagent-keys-configmap.yaml  -k
	curl -s $ARTI_REPO_URL/Linux/tcagent-init-configmap.yaml -o $CURRENT_DIR/tcagent-init-configmap.yaml  -k 
}

mkdir -p /opt/buildtools/
tar  -xvf ./kubectl.tar -C /opt/buildtools/
getAllBinaries
