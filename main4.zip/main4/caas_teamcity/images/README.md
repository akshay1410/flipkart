# TeamCity Docker images
This directory contains Dockerfiles and other files needed to customise the default TeamCity images.

## Building the images
1. Upload the `images` directory with its contents to a server/workstation with Docker on it.
2. Go into the directory for the image you want to build (agent or server), for this example we will build the server image.
   ```
   cd server
   ```
3. Build the new image. While this example uses a specific Harbor project (eppeng) and image tag (latest), they can be different in your case. 
   ```
   docker build -t harbor-pks-dev.server.rbsgrp.net/eppeng/teamcity-server:latest .
   ```
3. Push the new image to the repository.
   ```
   docker push harbor-pks-dev.server.rbsgrp.net/eppeng/teamcity-server:latest
   ```
4. Delete the images from your local instance of docker. Don't worry, this won't delete the image you have pushed to Harbor.
   ```
   docker rmi harbor-pks-dev.server.rbsgrp.net/eppeng/teamcity-server:base
   docker rmi harbor-pks-dev.server.rbsgrp.net/eppeng/teamcity-server:latest
   ```