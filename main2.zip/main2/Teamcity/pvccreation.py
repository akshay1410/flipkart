#!/usr/bin/python
############################## Utility to monitor cloudprofiles ##########################################

#!/usr/bin/python

# encoding: utf-8

import threading
import unicodedata
import logging
import os
import datetime
import time
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pprint
import urllib
import urllib2
import httplib
import base64
import xml.sax
import xml.dom
from xml.dom import minidom
import StringIO
import fnmatch
import urlparse
import xml.etree.ElementTree as ET
import json
import subprocess
import yaml
from zipfile import ZipFile


################################### #Passed arguments handling and assigning them to variables #######################################################


totalargs = len(sys.argv)
reqargs = 6

if totalargs < reqargs:
    print ("usage:  {APIserver: apiservername } {svcaccountname: namespace service account} {namespace: projectnamespace} {token:namespacetoken} {storageclass:pvstorageclassname}")
    exit(1)
else:
    #print ("Proceeding with cmd argument initialiation")

# #Passed arguments handling and assigning them to variables
namespace=str(sys.argv[3])
apiserver=str(sys.argv[1])
serviceaccount=str(sys.argv[2])
token=str(sys.argv[4])
storageclass=str(sys.argv[5])



##################Logger################

class SingletonType(type):
        _instances={}

        def __call__(cls, *args, **kwargs):
                if cls not in cls._instances:
                        cls._instances[cls]=super(SingletonType, cls).__call__(*args, **kwargs)
                return cls._instances[cls]

class MyLogger(object):
        __metaclass__ = SingletonType
        _logger=None

        def __init__(self):
                self._logger=logging.getLogger("crumbs")
                self._logger.setLevel(logging.DEBUG)
                formatter=logging.Formatter('%(asctime)s \t [%(levelname)s] | %(filename)s:%(lineno)s] > %(message)s')
                now=datetime.datetime.now()

                fileHandler=logging.FileHandler("cloudprofilemonitor_" + now.strftime("%Y-%m-%d") + ".log")
                streamHandler=logging.StreamHandler()
                fileHandler.setFormatter(formatter)
                streamHandler.setFormatter(formatter)

                self._logger.addHandler(fileHandler)
                self._logger.addHandler(streamHandler)

        def get_logger(self):
                return self._logger

logger=MyLogger.__call__().get_logger()

def time_difference(time_start, time_end):
        start = datetime.strptime(time_start, "%H%M")
        end = datetime.strptime(time_end, "%H%M")
        difference = end - start
        hours = difference.total_seconds() / 60 / 24
        return int(hours)



#main Function

#switching projectnamespace
output = subprocess.call(["./kubeconfiggen.sh","apiserver","serviceaccount","namespace","token"])
if output == 0:
        print "Your context has been switched successfully"
        output1 = subprocess.call(["./pvccreation.sh","namespace","storageclass"])
        if output1 == 0:
                print "PVC Creation completed successfully"
                exit 0
        else
                print "PVC creation failed"
                exit 1
else
        print "PVC creation failed" 
        exit 1

