#!/usr/bin/python
############################## Utility to monitor cloudprofiles ##########################################

#!/usr/bin/python

# encoding: utf-8

import threading
import unicodedata
import logging
import os
import datetime
import time
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import pprint
import urllib
import urllib2
import httplib
import base64
import xml.sax
import xml.dom
from xml.dom import minidom
import StringIO
import fnmatch
import urlparse
import xml.etree.ElementTree as ET
import json
import re
from zipfile import ZipFile


################################### #Passed arguments handling and assigning them to variables #######################################################


totalargs = len(sys.argv)
reqargs = 4

if totalargs < reqargs:
    print ("usage:  {username: teamcity username} {password: Username's password} {Teamcity URL:} ")
    exit(1)
else:
    print "projectname"+','+"profileInstanceLimit"+','+"terminate-idle-time"+','+"Status"

# #Passed arguments handling and assigning them to variables
teamcityurl=str(sys.argv[3])
username=sys.argv[1]
password=sys.argv[2]



##################Logger################

class SingletonType(type):
        _instances={}

        def __call__(cls, *args, **kwargs):
                if cls not in cls._instances:
                        cls._instances[cls]=super(SingletonType, cls).__call__(*args, **kwargs)
                return cls._instances[cls]

class MyLogger(object):
        __metaclass__ = SingletonType
        _logger=None

        def __init__(self):
                self._logger=logging.getLogger("crumbs")
                self._logger.setLevel(logging.DEBUG)
                formatter=logging.Formatter('%(asctime)s \t [%(levelname)s] | %(filename)s:%(lineno)s] > %(message)s')
                now=datetime.datetime.now()

                fileHandler=logging.FileHandler("cloudprofilemonitor_" + now.strftime("%Y-%m-%d") + ".log")
                streamHandler=logging.StreamHandler()
                fileHandler.setFormatter(formatter)
                streamHandler.setFormatter(formatter)

                self._logger.addHandler(fileHandler)
                self._logger.addHandler(streamHandler)

        def get_logger(self):
                return self._logger

logger=MyLogger.__call__().get_logger()

def time_difference(time_start, time_end):
        start = datetime.strptime(time_start, "%H%M")
        end = datetime.strptime(time_end, "%H%M")
        difference = end - start
        hours = difference.total_seconds() / 60 / 24
        return int(hours)

#fetching Cloudprofiles of the teamcity instance


#GEt request defination

def getRequest(username, password, url, contentType):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        req = urllib2.Request(url, "", {'Content-Type': contentType})
        req.add_header("Authorization", "Basic %s" % base64string)
        req.get_method = lambda: 'GET'
        return req

#main Function

url = teamcityurl + "/app/rest/cloud/profiles"
#logger.debug("URL..." + url)
#logger.debug("Creating Request Object.")
req = getRequest(username, password, url, 'application/xml')
#logger.debug("Connecting to TC Instance...")
response = urllib2.urlopen(req)
#logger.debug("Connected to " + url)
data=ET.fromstring(response.read())
#logger.debug("Fetched the API Data " + url)

cloudprofid = []

for cloudProfile in data.findall('cloudProfile'):
        #logger.debug("Fetching all cloud profiles id ")
        cloudprof =cloudProfile.get('id')
        cloudprofid.append(cloudprof)
#print(cloudprofid)


projectprofid = []
for prof in cloudprofid:
        url = teamcityurl + "/app/rest/cloud/profiles/id:" + prof
        #logger.debug("URL..." + url)
        #logger.debug("Creating Request Object.")
        req = getRequest(username, password, url, 'application/xml')
        #logger.debug("Connecting to TC Instance...")
        response = urllib2.urlopen(req)
        #logger.debug("Connected to " + url)
        data1=ET.fromstring(response.read())
        #logger.debug("Fetched the API Data " + url)
        for project in data1.findall('project'):
                #logger.debug("Fetching all cloud project id ")
                projectid =project.get('id')
                projectprofid.append(projectid)
projprofuniq = set(projectprofid)
projprofall = list(projprofuniq)
#print (projprofall)


url = teamcityurl + "/app/rest/userGroups"
#logger.debug("URL..." + url)
#logger.debug("Creating Request Object.")
req = getRequest(username, password, url, 'application/xml')
#logger.debug("Connecting to TC Instance...")
response = urllib2.urlopen(req)
#logger.debug("Connected to " + url)
data3=ET.fromstring(response.read())
#logger.debug("Fetched the API Data " + url)

usergroups=[]
for group in data3.findall('group'):
        #logger.debug("Fetching all cloud profiles id ")
        usergroup =group.get('name')
        usergroups.append(usergroup)
#print(usergroups)

r = re.compile(".*administrators")
usergroupsadmin = list(filter(r.match, usergroups)) # Read Note
print(usergroupsadmin)

for grp in usergroupsadmin:
    url = teamcityurl + "/app/rest/userGroups/name/id:" + grp
    #logger.debug("URL..." + url)
    #logger.debug("Creating Request Object.")
    req = getRequest(username, password, url, 'application/xml')
    #logger.debug("Connecting to TC Instance...")
    response = urllib2.urlopen(req)
    logger.debug("Connected to " + url)
    data4=ET.fromstring(response.read())
    #logger.debug("Fetched the API Data " + url)

scope=[]
    for role in data4.findall('role'):
        #logger.debug("Fetching all cloud profiles id ")
        projscope =role.get('scope')
        scope.append(projscope)
    scope1=list(map(lambda x: str(x).replace('p:', ''), scope))
    print(scope1)

finallist =[]
finallist1 = []
count=0
for proj in projprofall:
        url = teamcityurl + "/app/rest/projects/id:" + proj + "/projectFeatures"
        #logger.debug("URL..." + url)
        #logger.debug("Creating Request Object.")
        req = getRequest(username, password, url, 'application/xml')
        #logger.debug("Connecting to TC Instance...")
        response = urllib2.urlopen(req)
        #logger.debug("Connected to " + url)
        data2=ET.fromstring(response.read())
        #logger.debug("Fetched the API Data " + url)
        for property in data2.iter('property'):
                #print(property.attrib)
                #print(property.attrib['name'])
        #       print("projectname","profileInstanceLimit","terminate-idle-time")
        #       finallist=[proj]
                if property.attrib['name'] == "profileInstanceLimit" or property.attrib['name'] == "terminate-idle-time":
                        count = count + 1
                        #print("projectname","profileInstanceLimit","terminate-idle-time")
                        #finallist=[proj]
                        #if property.attrib['name'] == "profileInstanceLimit":
                                #finallist[1]=property.attrib['value'])
                        #elif property.attrib['name'] == "terminate-idle-time":
                                #finallist[2]=property.attrib['value'])
                        #else:
                                #finallist[0]=property.attrib['value'])         
                        finallist.append(property.attrib['value'])      
                        if count == 2:
                                #print(type(finallist[0]))
                                if int(finallist[0]) > 2 or int(finallist[1]) > 30:
                                        print proj+','+finallist[0]+','+finallist[1]+','+"failed"
                                else:
                                        print proj+','+finallist[0]+','+finallist[1]+','+"passed"       
                                
                                finallist=[]
                                count=0
                #       finallist1 = set(finallist)
                        #print("hello")
                #       print(proj,property.attrib['value'])
        #       break
       #         for prop in finallist:
        #              if prop == 'profileInstanceLimit' or prop == 'terminate-idle-time':  
        #                        finallist1.append(finallist)
#print (finallist)         