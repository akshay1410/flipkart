#!/bin/bash
#set -x

#########################################################################################################
#                       Check Change record using dws and snow broker                                   #
#                       Author: Akshay kumar                                                            #
#                       Date: April 22, 2021                                                            #
#########################################################################################################

#dws setup service account

mkdir -p /tmp/dws
cd /tmp/dws
curl -k -s -LO "https://artifactory.server.rbsgrp.net/artifactory/eetools-buildtools-local/Linux/dws.tar"
chmod +x /tmp/dws/dws.tar
tar -xf /tmp/dws/dws.tar -C /tmp/dws/

curl -k -s -LO "https://artifactory.server.rbsgrp.net/artifactory/eetools-buildtools-local/Linux/edt.toml"
chmod +x /tmp/dws/edt.toml
mv /tmp/dws/edt.toml /root/

/tmp/dws/dws orchestrator get change --id $1 >/tmp/dws/changeout.txt



changestatus=`/tmp/dws/dws orchestrator get change --id $1 | grep -i inApprovedWindow | awk -F: '{print $2}' | sed 's/,//g' | xargs`

if [ "$changestatus" == "true" ];
    then
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "Its a valid change record"
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "Please find the change details"
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    cat /tmp/dws/changeout.txt
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    elif [ "$changestatus" == "false" ];
    then
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "All necessary Change record criterias not met ."
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "Please find the change details"
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    cat /tmp/dws/changeout.txt
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    else
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "Please verify if its a valid change record .Note Incidents are not allowed"
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    echo " "
    echo "Please find the detailed status"
    echo " "
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    cat /tmp/dws/changeout.txt
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
    exit 1
    fi

#removing the dws and toml
rm -rf /tmp/dws/
rm /root/edt.toml