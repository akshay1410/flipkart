############################## Utility to copy permission target ##########################################

import requests
import json
import csv
import re
import warnings
warnings.simplefilter("ignore")
import sys

##################################### Log File Creation ######################################################

old_stdout = sys.stdout
log_file = open("/\\gbmlvfilfs09n02.rbsres01.net/home1$/KumaKcs/Profile/Desktop/Python_log_file/validation_script_permissions_target.log","w")
sys.stdout = log_file

#################################### Artifactory-1 #######################################################

lon_url1="https://artifactory-1.dts.fm.rbsgrp.net"
lon_url=lon_url1+"/artifactory/api/security/permissions"
headers = {'Content-type' : 'application/json'}
response1 = requests.get(lon_url, headers=headers, auth=('app-dtsadmin', 'BTVv8MSs'), verify=False)
lon_get_data = response1.json() ###### Get JSON Permission List for London
print("########################################## This is London based Artifactory Data #####################################################################")
print(lon_get_data)
print(len(lon_get_data))

#################################### Artifactory-EDC #######################################################

edc_url1="https://artifactory.server.rbsgrp.net"
edc_url=edc_url1+"/artifactory/api/security/permissions"
headers = {'Content-type' : 'application/json'}
response2 = requests.get(edc_url, headers=headers, auth=('app-dtsadmin', 'BTVv8MSs'), verify=False)
edc_get_data = response2.json() ##### Get JSON Permission List for EDC 
print("########################################## This is EDC based Artifactory Data #####################################################################")
print(edc_get_data)
print(len(edc_get_data))

#################################### Missing Permissions Artifactory #######################################################
'''
missing_lon_uri=[]
missing_edc_uri=[]

for missing_lon in lon_get_data:
    last=0
    for missing_edc in edc_get_data:
        if missing_lon['name'] == missing_edc['name']:
            pass
            last=1
    if last == 0: 
        missing_lon_uri.append(missing_lon['uri']) # Help us to find out the missing permsission target
        print(missing_lon_uri)
'''        
#################################### Comparison Permissions Targets Artifactory #######################################################      

permission_edc_list=[]
missing_lon_uri=[]
permission_lon_list=[]
for master_lon in lon_get_data:
    found = 0
    for master_edc in edc_get_data:
        if master_lon['name'] == master_edc['name']:
            found = 1
            permission_lon_list.append(master_lon['uri']) # GetPermission target name of London
            permission_edc_list.append(master_edc['uri']) # GetPermission target name of EDC
            
        else:
            pass
       
    if found == 0:
        missing_lon_uri.append(master_lon['uri'])
      
# print(permission_lon_list)
# print(len(permission_lon_list))
# print(missing_lon_uri)
# print(len(missing_lon_uri))
# print(permission_edc_list)
# print(len(permission_edc_list))
        
         
############################## Getting Permission Target Details ####################################
lon_list=[]
edc_list=[]
for perm_target_lon in permission_lon_list:
    headers = {'Content-type' : 'application/json'}
    response5 = requests.get(perm_target_lon, headers=headers, auth=('app-dtsadmin', 'BTVv8MSs'), verify=False)
    json_data_lon = response5.json()
    lon_list.append(json_data_lon) # Get JSON London data and append it into list
    #print(lon_list)
for perm_target_edc in permission_edc_list:
    headers = {'Content-type' : 'application/json'}
    response6 = requests.get(perm_target_edc, headers=headers, auth=('app-dtsadmin', 'BTVv8MSs'), verify=False)
    json_data_edc = response6.json()
    edc_list.append(json_data_edc) # Get JSON EDC data and append it into list
print("##########################################  JSON Data of Artifactory-London #####################################################################")
print(lon_list) 
print(len(lon_list))
print("########################################## JSON Data of Artifactory-EDC #####################################################################")
print(edc_list)
print(len(edc_list))

#################################### Data Comparision Repos,Groups and Users  ########################################################
    
with open('/\\gbmlvfilfs09n02.rbsres01.net/home1$/KumaKcs/Profile/Desktop/Python_log_file/artifactory_validation_permissions-target.csv', 'w', newline='') as f:
    fnames = ['Permission-Name', 'Missing-Repos', 'Missing-Groups', 'Missing-Users']
    writer = csv.DictWriter(f, fieldnames=fnames)
    writer.writeheader()
    # print("Test")
    for lon_repo in lon_list: 
        end = 0
        missing_repos = []
        missing_users = []
        missing_groups = []
        for edc_repo in edc_list:
            if lon_repo['name'] == edc_repo['name']:
                end = 1
                for repo in lon_repo['repositories']:
                        if repo in edc_repo['repositories']:
                            continue        
                        else:
                            missing_repos.append(repo) # Append the missing repositories
                print(missing_repos)
                for principals_lon_key, principals_lon_value in lon_repo['principals'].items():
                    for principals_edc_key, principals_edc_value in edc_repo['principals'].items():
                        if principals_lon_key == "groups" and principals_lon_key == principals_edc_key:   ## Filtering data for Groups
                           for lon_grp_key, lon_grp_value in principals_lon_value.items():
                               count=0
                               for edc_grp_key, edc_grp_value in principals_edc_value.items(): 
                                   if lon_grp_key in edc_grp_key:  ## Comparing groups with London to EDC 
                                       count=1
                                       pass
                                
                               if count == 0:
                                   missing_groups.append(lon_grp_key)  ## Extracting missing groups
                               print(lon_repo['name'])       
                               print("missing groups:",missing_groups)
                               
                        elif principals_lon_key == "users" and principals_lon_key == principals_edc_key:  ## Filtering data for Users
                            for lon_usr_key, lon_usr_value in principals_lon_value.items():
                                terminate=0
                                for edc_usr_key, edc_usr_value in principals_edc_value.items():
                                    if lon_usr_key in edc_usr_key:     ## Comparing users with London to EDC
                                        terminate=1
                                        pass
                                if terminate==0:
                                    missing_users.append(lon_usr_key)  ## Extracting missing users
                            print(lon_repo['name'])
                            print("missing users:",missing_users)
                writer.writerow({'Permission-Name': lon_repo['name'], 'Missing-Repos': missing_repos, 'Missing-Groups': missing_groups, 'Missing-Users': missing_users})  
                            

sys.stdout = old_stdout
log_file.close()
