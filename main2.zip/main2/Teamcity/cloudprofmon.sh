#!/bin/sh
#!/bin/bash
#set -x
#########################################################################################################
#                       Script for checking teamcity cloud profile parameters                           #
#                       Author: Akshay kumar                                                            #
#                       Date: March 9 , 2021                                                            #
#########################################################################################################


#Passed arguments handling and assigning them to variables
teamcityurl=$3
username=$1
password=$2

# Validate the script's Arguments
if [[ $# -lt 3 ]] ; then
    echo "usage:  {username: teamcity username} {password: Username's password} {Teamcity URL:} "
    exit 1
fi


#  Fetching All CLoud Profiles on the instance 

curl -k -s -u admin:password123 $teamcityurl/app/rest/cloud/profiles >temp-allcloudprof.xml

allcloudprof=( $(echo "cat //cloudProfile/@id" | xmllint --shell temp-cloudprof.xml |grep id | cut -d \" -f2) )

for profile in ${allcloudprof[@]}
    do  
        curl -k -s -u admin:password123 $teamcityurl/app/rest/cloud/profiles/id:${allcloudprof[profile]} >prof-tmp.xml
        projectid=( $(echo "cat //project/@id" | xmllint --shell prof-tmp.xml |grep id | cut -d \" -f2) )
        curl -k -s -u admin:password123 $teamcityurl/app/rest/projects/id:$projectid/projectFeatures >projfeatures-tmp.xml
        
         

