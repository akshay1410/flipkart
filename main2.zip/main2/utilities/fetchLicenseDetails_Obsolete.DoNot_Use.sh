#!/bin/sh

## Created By - Amit Khurana
## Created On - 26-Sep-2017
## Get License Details


username=$1
password=$2
totalLicenses=""
remainingLicenses=""
daysBeforeExpiring=""

## REST Endpoint for all Plugins - https://jira-dts.fm.rbsgrp.net/rest/plugins/1.0/

if [ -f  "/dts_data0/Scripts/Monitoring/desToolAppsList.csv"  ]
then
        echo "DESToolsApp,TotalLicenses,FreeLicenses,DaysRemaining/Expiring On"
        while IFS=, read -r col1 col2 col3
        do
                if [ "${col1}" == "jira" ] && [ "${col2}" == "jira-dts"  ]
                then
                        output=`curl -D -s -S -k -u $username:$password -X GET -H "Content-Type: application/json" "${col3}/rest/plugins/1.0/com.atlassian.servicedesk-key/license" &> licenseDetails`
                        totalLicenses=`cat licenseDetails  | awk -F"links" '{print $NF}' | sed "s/,/ /g" | awk -F"maximumNumberOfUsers" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        remainingLicenses="${totalLicenses}"
                        daysBeforeExpiring=`cat licenseDetails  | awk -F"links" '{print $NF}' | sed "s/,/ /g" | awk -F"expiryDateString" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        echo "Jira ServiceDesk,${totalLicenses//[$'\t\r\n ']},${remainingLicenses//[$'\t\r\n ']},${daysBeforeExpiring//[$'\t\r\n ']}"
                        ## Actual JIRA Software License REST Endpoint - https://jira-dts.fm.rbsgrp.net/rest/plugins/applications/1.0/installed/jira-software/license
                        output=`curl -D -s -S -k -u $username:$password -X GET -H "Content-Type: application/json" "${col3}/rest/api/2/applicationrole" &> licenseDetails`
                        totalLicenses=`cat licenseDetails  | awk -F"key" '{print $NF}' | sed "s/,/ /g" | awk -F"numberOfSeats" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        remainingLicenses=`cat licenseDetails  | awk -F"key" '{print $NF}' | sed "s/,/ /g" | awk -F"remainingSeats" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        output=`curl -D -s -S -k -u $username:$password -X GET -H "Content-Type: application/json" "${col3}/rest/plugins/applications/1.0/installed/jira-software/license" &> licenseDetails`
                        daysBeforeExpiring=`cat licenseDetails  | awk -F"key" '{print $NF}' | sed "s/,/ /g" | awk -F"expiryDateString" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        echo "Jira Software,${totalLicenses//[$'\t\r\n ']},${remainingLicenses//[$'\t\r\n ']},${daysBeforeExpiring//[$'\t\r\n ']}"
                elif [ "${col1}" == "bitbucket" ]
                then
                        output=`curl -D -s -S -k -u $username:$password -X GET -H "Content-Type: application/json" "${col3}/rest/api/1.0/admin/license" &> licenseDetails`
                        totalLicenses=`cat licenseDetails  | sed "s/,/ /g" | awk -F"maximumNumberOfUsers" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        currentNumberOfUsers=`cat licenseDetails  | awk -F"key" '{print $NF}' | sed "s/,/ /g" | awk -F"currentNumberOfUsers" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        remainingLicenses=`expr ${totalLicenses} - ${currentNumberOfUsers}`
                        daysBeforeExpiring=`cat licenseDetails  | awk -F"key" '{print $NF}' | sed "s/,/ /g" | awk -F"numberOfDaysBeforeExpiry" '{print $2}' | awk '{print $1}' | sed "s/\"://g"`
                        echo "Bitbucket,${totalLicenses//[$'\t\r\n ']},${remainingLicenses//[$'\t\r\n ']},${daysBeforeExpiring//[$'\t\r\n ']}"
                fi
        done < "/dts_data0/Scripts/Monitoring/desToolAppsList.csv"
fi