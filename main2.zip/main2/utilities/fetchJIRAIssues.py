#!/usr/bin/python

## Created By - Amit Khurana
## Created On - 05-Feb-2016

## The purpose of this script is to fetch all JIRA issues related to a Project and fetch all attachments
## related to each JIRA and dowmload them as zip.

import csv
import sys
import pprint
import urllib2
import base64
import xml.sax
import xml.dom
from xml.dom import minidom
import StringIO

username = 'jira_ak'
password = "password"
rownum = 0
issuenum = 0

response = object()
try:
	url = "https://jira.dts.fm.rbsgrp.net/rest/api/2/search?jql=project = LUXBG AND created >= 2013-05-03 AND created <= 2016-02-01 AND workratio >= "0" AND workratio <= "1000" ORDER BY key ASC"
	base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
	base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
	req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
	req.add_header("Authorization", "Basic %s" % base64string)
	req.get_method = lambda: 'GET'
	response = urllib2.urlopen(req)
	content = response.read()
	xmldoc = minidom.parse(StringIO.StringIO(content))
	for element in xmldoc.getElementsByTagName('issues'):
    		for element in xmldoc.getElementsByTagName('group'):
				attr = element.attributes["name"]
				if attr:
					#print attr.name + " " + attr.value
					if "stash" in attr.value.strip().lower():
						print "Group " + attr.value + " found for user " + racfid + ". "
						url = "https://uatcrowd-dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user/group/direct?username=%s&groupname=%s"  % (racfid.strip(), attr.value.strip().lower())
						base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
						base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
						req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
						req.add_header("Authorization", "Basic %s" % base64string)
						req.get_method = lambda: 'DELETE'
						try:
							response = urllib2.urlopen(req)
							print "Response for: " +  racfid + " " +  attr.value + " - " + response.read()
						except urllib2.HTTPError, error:
							content = error.read()
							print "Response for: " +  racfid + " " +  attr.value + " - " + content
				else:
					content = "No groups attached to" + racfid.strip()
				groupnum += 1
		except urllib2.HTTPError, error:
			content = error.read()
			print "Response For racfid: " + racfid.strip() + " " + content
		rownum += 1
finally:
    f.close()
    #logFile.close()

