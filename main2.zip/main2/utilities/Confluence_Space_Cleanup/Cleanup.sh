#!/bin/bash

###
###     java_home = ~goyahii/jdks/*
###     confluece_cli = /home/goyahii/atlassian-cli-2.0.0
###

CWD=`pwd`
echo "Current Working Directory = $CWD"

## setup cli
echo "Setting up atlassian CLI for running this utility"
wget --no-check-certificate https://artifactory-1.dts.fm.rbsgrp.net/artifactory/simple/dts-ext-local/com/atlassian/atlassian-cli-2.0.0-distribution.zip
unzip atlassian-cli-2.0.0-distribution.zip



#set env
#JAVA_HOME="/home/goyahii/jdks/jdk1.8.0_31"
#PATH="$JAVA_HOME/bin:$PATH"

#CCLI="/home/goyahii/atlassian-cli-2.0.0/confluence.sh"
CCLI="$CWD/atlassian-cli-2.0.0/confluence.sh"
CSERVER="http://confluence.dts.fm.rbsgrp.net"
JCLI="$CWD/atlassian-cli-2.0.0/conf/jira.sh"
#JSERVER_1="http://"

SPACE_DETAILS="$CWD/Confluence_Space_Cleanup/Space.details"
#SPACE_DETAILS="/home/goyahii/Confluence_Space_Cleanup/Space.details"

#test list
#SPACE_KEY="$CWD/Confluence_Space_Cleanup/spacelist.spacekey.him"
#original list
SPACE_KEY="$CWD/Confluence_Space_Cleanup/spacelist.spacekey.orig"

env

## setting user credentials
#. /home/goyahii/userpass
. /opt/app/dts/teamcity/userpass.temp

TLIST=`wc -l ${SPACE_KEY}`
echo "Total number of Confluence spaces to be deleted = $TLIST"


rm -v ${SPACE_DETAILS}
echo "Generating space details in csv format ... "
i=1
while read LINE
do
spkey="$LINE"
echo "Space key = $LINE"
#SDETAILS=`$CCLI --action getSpace --space "$LINE" --server $CSERVER --user $CUSER --password $CPASS`
$CCLI --action getSpace --space "$LINE" --server $CSERVER --user $CUSER --password $CPASS
#$CCLI --action getSpace --space "$LINE" --server $CSERVER --user $CUSER --password $CPASS >> ${SPACE_DETAILS}
echo "Deleting Space $LINE"
echo "Status : $i / $TLIST"
i=$(($i+1))
$CCLI --action removeSpace --space "$LINE" --server $CSERVER --user $CUSER --password $CPASS
echo "============================="
done < ${SPACE_KEY}


##remove cli
echo "Cleaning up CLI setup done for running this utility"
rm -v atlassian-cli-2.0.0-distribution.zip
rm -rf atlassian-cli-2.0.0-distribution




