#!/bin/bash
# Get repositories and corresponding group mapping

LOCATION=/dts_data0/ToolsConfiguration/SVN/cluster/svnsh/apache/conf/dts_svn_locations.conf

cat $LOCATION | grep -v "#" | grep "<Location " | awk '{print $NF}'  > svn_file1.txt

echo "[" > json_file.txt
#echo "["

i="1"

for line in `cat svn_file1.txt` ;
do
        REPO_NAME=`echo $line | awk '{print $NF}' | sed "s/\///g" | sed "s/>//g"`
        AUTHZ_FILE=`cat $LOCATION | grep -A 18 $line | grep "CrowdAuthzSVNAccessFile" | awk '{print $NF}'`

        GROUP_NAME=""
        if [ -f "$AUTHZ_FILE" ]
        then
                for line1 in `cat $AUTHZ_FILE | grep -v "#" | grep "@" | grep -v "dts-administrators" | sed "s/\@//g" | awk '{print $1}' | sort| uniq` ;
                do
                        if [ "$GROUP_NAME" == "" ]
                        then
                                GROUP_NAME=`echo "\"$line1\""`
                        else
                                GROUP_NAME=`echo "$GROUP_NAME, \"$line1\""`
                        fi
                done
        fi

        if [ "$i" == "1" ]
        then
                echo "  {" >> json_file.txt
                echo "          \"key\": \"$REPO_NAME\"," >> json_file.txt
                echo "          \"name\": \"$REPO_NAME\"," >> json_file.txt
                echo "          \"groups\": [$GROUP_NAME]" >> json_file.txt
                i="2"
        else
                echo "  }," >> json_file.txt
                echo "  {" >> json_file.txt
                echo "          \"key\": \"$REPO_NAME\"," >> json_file.txt
                echo "          \"name\": \"$REPO_NAME\"," >> json_file.txt
                echo "          \"groups\": [$GROUP_NAME]" >> json_file.txt
        fi

#        if [ "$i" == "1" ]
#        then
#                echo "  {"
#                echo "          \"key\": \"$REPO_NAME\","
#                echo "          \"name\": \"$REPO_NAME\","
#                echo "          \"groupName\": [$GROUP_NAME]"
#                i="2"
#        else
#                echo "  },"
#                echo "  {"
#                echo "          \"key\": \"$REPO_NAME\","
#                echo "          \"name\": \"$REPO_NAME\","
#                echo "          \"groupName\": [$GROUP_NAME]"
#        fi
done

echo "  }" >> json_file.txt
echo "]" >> json_file.txt
#echo "  }"
#echo "]"
