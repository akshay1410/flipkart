Scripts are for:
- Project archival

Project archive and restore instructions are captured at https://confluence.dts.fm.rbsgrp.net/display/ECTFT2/SQ+5.6+housekeeping+SOP

Note: This script works with v5.6.3 and v7.9.1