#!/bin/bash
### This script does following things:
###     1) takes project export 
###     2) validate the export
###	    	a) if success - capture the response and delete the project
###			b) if fails - capture the error details
###		3) publish the housekeeping report somewhere
### Written by: europa\agrawgb

CWD=`pwd`

### Inputs
inputFilename=$1
sonarURL=$2
authToken=$3

if [[ $# -lt 3 ]] ; then
    echo "usage: {inputFilename: should be in data folder} {sonarURL: http://localhost:9898} {authToken: Must have admin privileges}"
    exit 1
fi

echo "Current working directory = $CWD"
inputFilepath="$CWD/../data/$inputFilename"

echo "Following are the inputs provided:"
echo "inputFilepath: $inputFilepath"
echo "sonarURL: $sonarURL"

echo "Validating the token.."
curl --insecure --silent -u "${authToken}:" "$sonarURL/api/authentication/validate" -o token-response.txt
TOKEN_RESPONSE=`cat token-response.txt`
if echo "$TOKEN_RESPONSE" | grep -q "false"; then
	echo "Token is invalid, please check."
	exit 1;
else
	echo "Token is valid, moving further.."
fi

OVERALL_RESPONSE_FILE="$CWD/../data/output-$(date +'%d%m%Y').projects"
echo "projectKey,status,message" > $OVERALL_RESPONSE_FILE

### read the file
FILE_DATA="$inputFilepath"

TLIST=`cat ${FILE_DATA} | wc -l`
echo "Total number of Sonar projects to be archived = $TLIST"

i=1
while read LINE
	do
	PROJECT_KEY=`echo "$LINE"|cut -d, -f1`
	LAST_ANALYSED=`echo "$LINE"|cut -d, -f2`
	LOC=`echo "$LINE"|cut -d, -f3`
	echo "$i / $TLIST ::: Going to archive the project::: PROJECT_KEY = $PROJECT_KEY, LAST_ANALYSED = $LAST_ANALYSED, LOC = $LOC"
	echo "Trigger export job for $PROJECT_KEY"
	curl --insecure --silent -u "${authToken}:" -X POST "$sonarURL/api/project_dump/export?key=$PROJECT_KEY" -o job-response.txt
	JOB_RESPONSE=`cat job-response.txt`
	echo "JOB_RESPONSE::: $JOB_RESPONSE"

	if echo "$JOB_RESPONSE" | grep -E "err_code|errors"; then
		# code if found
		echo "Error has occured. project export failed"
		echo "$PROJECT_KEY,FAILED,$JOB_RESPONSE" >> $OVERALL_RESPONSE_FILE
	else
		# code if not found
		TIME_COUNTER=1;
		PROJECT_EXPORTED="false";
		echo "Check the export job completion status for 3 minute and every 5 secs"
		while 
			sleep 5; 
			do curl --insecure --silent -u "${authToken}:" "$sonarURL/api/project_dump/status?key=$PROJECT_KEY" -o status-response.txt
			STATUS_RESPONSE=`cat status-response.txt`
			echo "STATUS_RESPONSE::: $STATUS_RESPONSE"
			if echo "$STATUS_RESPONSE" | grep -q "exportedDump"; then
				echo "Project $PROJECT_KEY exported successfully."
				PROJECT_EXPORTED="true";
				break;
			else
				if [[ $TIME_COUNTER -eq 36 ]] ; then
					break;
				fi
				TIME_COUNTER=$(($TIME_COUNTER+1))
			fi
		done
		
		# Delete the project, if exported successfully
		if [[ $PROJECT_EXPORTED == "true" ]] ; then
			echo "Going to delete the project..."
			curl --insecure --silent -u "${authToken}:" -X POST "$sonarURL/api/projects/delete?key=$PROJECT_KEY" -o project-delete-response.txt
			DELETE_RESPONSE=`cat project-delete-response.txt`
			if [[ $DELETE_RESPONSE == "" ]]; then
				echo "Project delete job triggered"
				echo "$PROJECT_KEY,PASSED,'Project delete job triggered::: $STATUS_RESPONSE'" >> $OVERALL_RESPONSE_FILE
			else
				echo "Error has occured. project delete has failed"
				echo "$PROJECT_KEY,FAILED,'Error has occured. project delete has failed::: '$DELETE_RESPONSE" >> $OVERALL_RESPONSE_FILE
			fi
		else
			echo "Error has occured. project export failed and did not finish the export within 3 minute"
			echo "$PROJECT_KEY,FAILED,'Error has occured. project export failed and did not finish the export within 3 minute'" >> $OVERALL_RESPONSE_FILE
		fi
	fi
	i=$(($i+1))
	echo "======================================================================================================"
done < ${FILE_DATA}

rm -f token-response.txt project-delete-response.txt status-response.txt job-response.txt

echo "Projects archival is completed and reports are at {$OVERALL_RESPONSE_FILE}"
