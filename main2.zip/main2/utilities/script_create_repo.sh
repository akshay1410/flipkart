SCRIPT_DIR="/dts_data0/Scripts/SVN/PROD/Automation_RepoCreation"


if [ -f ${SCRIPT_DIR}/RepoInputs.txt ]
then
		rm ${SCRIPT_DIR}/RepoInputs.txt
fi
echo "BUSINESS_AREA='%env.businessArea%'" >> ${SCRIPT_DIR}/RepoInputs.txt
echo "LOCATION='%env.location%'"  >> ${SCRIPT_DIR}/RepoInputs.txt
echo "CROWD_GROUP_BASENAME='%env.crowdGroupBasename%'"  >> ${SCRIPT_DIR}/RepoInputs.txt
echo "CHANGE_REQUEST_ID='%env.changeRequestID%'"  >> ${SCRIPT_DIR}/RepoInputs.txt
. ${SCRIPT_DIR}/RepoInputs.txt

if [ -z $BUSINESS_AREA ] || [ -z $LOCATION ] || [ -z $CROWD_GROUP_BASENAME ] || [ -z $CHANGE_REQUEST_ID ]
then
        echo -e "\t\t\nPlease check and rectify RepoInputs.txt. It seems value of any variable is missing\n"
        exit 1
fi

BASE_SVN_DIR=/dts_data0/AppData/SVN
TEMPLATE_INITIAL_IMPORT="${SCRIPT_DIR}/Template_Initial_Import"
TEMPLATE_AUTHZFILE="${SCRIPT_DIR}/Template.authz"
TEMPLATE_CR_IMPLEMENTATION="${SCRIPT_DIR}/Template_ImplementationPlan.txt"
CR_IMPLEMENTATION_WORKSHEET="${SCRIPT_DIR}/CR${CHANGE_REQUEST_ID}_ImplementationPlan.txt"
CR_IMPLEMENTATION_BACKUP_WORKSHEET="${CR_IMPLEMENTATION_WORKSHEET}.$$"
BUSINESS_AREA_DIR="${BASE_SVN_DIR}/${BUSINESS_AREA}"
CONFIG_DIR="${BUSINESS_AREA_DIR}/conf"
SVN_AUTHZ_FILE="${CONFIG_DIR}/${LOCATION}.authz"
SVN_PATH="${BUSINESS_AREA_DIR}/$LOCATION"
HOOKS_SCRIPTS_PATH=/dts_data0/ToolsConfiguration/SVN/standard_hooks/dtsintegration/trunk/hooks/master
LOG_FILE="${SCRIPT_DIR}/output.log"

> ${LOG_FILE}

if [ ! -d ${BUSINESS_AREA_DIR} ]
then
        echo "Creating Business Area Directory :: ${BUSINESS_AREA_DIR}" > ${LOG_FILE}
        mkdir ${BUSINESS_AREA_DIR}
fi

if [ ! -d ${SVN_PATH} ]
then
        echo "Creating SVN Repository :: ${SVN_PATH}" >> ${LOG_FILE}
        svnadmin create ${SVN_PATH}
        if [ "$?" -eq 0 ]
		then
                cd ${SVN_PATH}/hooks
                echo "Copying dts_svn_sync.cfg to SVN Repo hooks directory" >> ${LOG_FILE}
                cp ${SCRIPT_DIR}/dts_svn_sync.cfg ${SVN_PATH}/hooks
                echo "Importing Initial directory Structure and creating links in hooks folder" >> ${LOG_FILE}
                svn import --username dtsadmin --password xyz -m "Initial folder structure import" ${TEMPLATE_INITIAL_IMPORT} "file://${SVN_PATH}"
                ln -s ${HOOKS_SCRIPTS_PATH}/post-commit ${SVN_PATH}/hooks/post-commit
                ln -s ${HOOKS_SCRIPTS_PATH}/multi_region_svn_sync.sh ${SVN_PATH}/hooks/multi_region_svn_sync.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/sync_ldn_slave.sh ${SVN_PATH}/hooks/sync_ldn_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/sync_hk_slave.sh ${SVN_PATH}/hooks/sync_hk_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/sync_us_slave.sh ${SVN_PATH}/hooks/sync_us_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/sync_in_slave.sh ${SVN_PATH}/hooks/sync_in_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/post-revprop-change ${SVN_PATH}/hooks/post-revprop-change
                ln -s ${HOOKS_SCRIPTS_PATH}/revprop_sync_us_slave.sh ${SVN_PATH}/hooks/revprop_sync_us_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/revprop_sync_in_slave.sh ${SVN_PATH}/hooks/revprop_sync_in_slave.sh
                ln -s ${HOOKS_SCRIPTS_PATH}/revprop_sync_hk_slave.sh ${SVN_PATH}/hooks/revprop_sync_hk_slave.sh
        else
                echo "Repository creation failed" >> ${LOG_FILE}
                echo -e "\t\t\nExiting the script as Repository creation failed\n"
                exit 1
        fi
else
        echo "SVNPATH ${SVN_PATH} already exists" >> ${LOG_FILE}
        echo -e "\t\t\nExiting the script as SVNPATH ${SVN_PATH} already exists\n"
        exit 1
fi
if [ ! -d ${CONFIG_DIR} ]
then
        echo "Creating conf directory :: ${CONFIG_DIR}" >> ${LOG_FILE}
        mkdir ${CONFIG_DIR}
fi

###### Creating SVN access file ########
if [ -f ${SVN_AUTHZ_FILE} ]
then
        echo -e "\t\t\n${SVN_AUTHZ_FILE} already exists\n"
        exit 1
else
        echo -e "\t\t\nCreating SVN Authz file :: ${SVN_AUTHZ_FILE}\n"
        cp ${TEMPLATE_AUTHZFILE} ${SVN_AUTHZ_FILE}
        sed -i "s#CROWD_GROUP_BASENAME#$CROWD_GROUP_BASENAME#g" ${SVN_AUTHZ_FILE}
fi

###### Creating CR Implementation steps worksheet ########
echo "Creating CR Implementation steps worksheet :: ${CR_IMPLEMENTATION_WORKSHEET}" >> ${LOG_FILE}
if [ -f ${CR_IMPLEMENTATION_WORKSHEET} ]
then
        cp ${CR_IMPLEMENTATION_WORKSHEET} ${CR_IMPLEMENTATION_BACKUP_WORKSHEET}
fi
cp ${TEMPLATE_CR_IMPLEMENTATION} ${CR_IMPLEMENTATION_WORKSHEET}
sed -i "s#<BASE_SVN_DIR>#$BASE_SVN_DIR#g" ${CR_IMPLEMENTATION_WORKSHEET}
sed -i "s#<LOCATION>#$LOCATION#g" ${CR_IMPLEMENTATION_WORKSHEET}
sed -i "s#<BUSINESS_AREA>#$BUSINESS_AREA#g" ${CR_IMPLEMENTATION_WORKSHEET}
