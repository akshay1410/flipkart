#!/bin/sh

## Created By - Amit Khurana
## Created On - 27-Sep-2017
## Monitor System Resources and echo results using dstat
## This checks only disk i/o only as of now

SERVER=$1


#dstat -tdnpr --fs --output sysoutput.`date +%m-%d-%y` 1 3 &> /dev/null
#dstat -tdnpr --fs --output sysoutput.`date +%m-%d-%y` 1 3 &> /dev/null
#awk 'FNR>5{print}' sysoutput.`date +%m-%d-%y`
#rm sysoutput.`date +%m-%d-%y`
`ps -A | grep java | cut -d ' ' -f1,5 > javaProcess.${SERVER}`
for pid in `cat javaProcess.${SERVER}`; do
        `pidstat -p ${pid} -hurd > ${pid}.tmp`
        `sed '1d;/^$/d;s/^[#]*//;s/^[ ]*//;s/[ ]\+/,/g' ${pid}.tmp | cut -d, -f1 --complement > ${pid}.csv`
        rm ${pid}.tmp
        cat ${pid}.csv
        rm ${pid}.csv
done