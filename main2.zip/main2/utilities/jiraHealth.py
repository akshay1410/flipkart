#!/usr/bin/python

## Created By - Amit Khurana
## Created On - 23-Feb-2018


import csv
import sys
import pprint
import urllib
import urllib2
import base64
import xml.sax
import xml.dom
import httplib
from xml.dom import minidom
import StringIO
import xml.etree.ElementTree as ET

if len (sys.argv) != 3 :
    print "Usage: python jiraHealth.py <username> <password> "
    sys.exit (1)

username = str(sys.argv[1])
password = str(sys.argv[2])

healthSupportUrl="https://jira-dts.fm.rbsgrp.net/rest/supportHealthCheck/1.0/check/"
base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
req = urllib2.Request(healthSupportUrl, "", {'Content-Type': 'application/xml'})
handler = urllib2.HTTPHandler(debuglevel=1)
opener = urllib2.build_opener(handler)
urllib2.install_opener(opener)
req.add_header("Authorization", "Basic %s" % base64string)
req.get_method = lambda: 'GET'

try:
        response = urllib2.urlopen(req)
        content = response.read()
except (httplib.HTTPException,urllib2.HTTPError) as err:
        content = err.read()
        e = ET.ElementTree(ET.fromstring(content))
        root = e.getroot()
        print "Column,Application,Severity,IsHealthy,Reason"
        for status in root:
                tag = status.find("tag")
                description = status.find("description")
                isHealthy = status.find("isHealthy")
                failureReason = status.find("failureReason")
                failureReason = failureReason.text.replace(",", ";")
                application = status.find("application")
                time = status.find("time")
                severity = status.find("severity")
print  "AppStatus," + application.text + "," + severity.text + "," + isHealthy.text + ",\"" + failureReason + "\""