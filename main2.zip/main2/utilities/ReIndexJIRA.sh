#!/bin/bash


## Created By - Amit Khurana
## Created On - 24-Jul-2017
## Reindex JIRA Instance

#!/bin/sh
LOG_FILE="reindex.log"
#exec 3>&1 1>>${LOG_FILE} 2>&1

username=$1
password=$2
server=$3
background=$4
monitor=true
debug=1
echo
echo "$(date +%Y-%m-%d_%T) Logging In"
echo "$(date +%Y-%m-%d_%T) Starting Re-indexing..."
if [[ "$background" == "true" ]]; then
        output=`curl -D- -s -S -k -u $username:$password -X POST -H "Content-Type: application/json" "${server}/rest/api/2/reindex"`
        if [[ $? != 0 ]]; then
                echo Error: $?: $!
                exit 1
        fi

        echo "$(date +%Y-%m-%d_%T) Background Reindex Started"
else
        output=`curl -D- -s -S -k -u $username:$password -X POST -H "Content-Type: application/json" "${server}/rest/api/2/reindex?type=FOREGROUND"`
        if [[ $? != 0 ]]; then
                echo Error: $?: $!
                exit 1
        fi

        echo "$(date +%Y-%m-%d_%T) Foreground Re-index Started"
fi
if [[ $debug == 1 ]]; then
        echo ------------------- Http raw response ---------------------------
        echo $output
        echo ------------------- ---------------------------
fi
until [[ $progress -eq 100 || "$monitor" != "true" ]]
do
        sleep 5
        output=`curl -s -S -k -u $username:$password -X GET -H "Content-Type: application/json" "${server}/rest/api/2/reindex" `
        if [[ $debug == 1 ]]; then
                echo ------------------- Http raw response ---------------------------
                echo $output
                echo ------------------- ---------------------------
        fi
        progress=`echo $output | cut -d "," -f 2 | cut -d ":" -f 2`
        if [ "$oldprog" != "$progress" ]; then
            taskid=`echo $output | cut -d "," -f 1 | cut -d ":" -f 2 | cut -d "=" -f 2 | awk '{ print substr( $0, 0, 5) }'`
            success=`echo $output | cut -d "," -f 8 | cut -d ":" -f 2 | cut -d "}" -f 1`
            #echo $output
            acknowledge="${server}/secure/admin/jira/AcknowledgeTask.jspa?taskId=${taskid}&amp;destinationURL=%2Fsecure%2Fadmin%2Fjira%2FIndexAdmin.jspa%3FreindexTime%3D246&amp;Acknowledge=Acknowledge&amp;atl_token=${atl_token}"
            echo "$(date +%Y-%m-%d_%T) Index is at ${progress}%..."
        fi
        oldprog=$progress
done
echo "$(date +%Y-%m-%d_%T) Task ID: ${taskid}"
echo "$(date +%Y-%m-%d_%T) Re-index Success: ${success}"
if [[ $success = "true" && $progress -eq 100 ]]; then
echo "$(date +%Y-%m-%d_%T) Re-index completed Successfully, sending Acknowledgement."
    output=`curl -s -S -k -u $username:$password -X GET -H "X-Atlassian-Token: no-check" -H "Content-Type:  text/html" "${acknowledge}"`
    if [[ $? != 0 ]]; then
                echo Error: $?: $!
                exit 1
    fi
    echo "$(date +%Y-%m-%d_%T) Successfully Acknowledged."
    if [[ $debug == 1 ]]; then
            echo ------------------- Http raw response ---------------------------
            echo $output
            echo ------------------- ---------------------------
    fi
fi
exit 0