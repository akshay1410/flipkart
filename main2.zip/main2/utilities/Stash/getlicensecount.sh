#!/bin/sh
`curl -k -u win-dtsadmin:Wrg2p\!c https://stash.dts.fm.rbsgrp.net/rest/api/1.0/admin/license &> json`
json_data=`cat json`
obj_arr=(${json_data//,/ })
maxLicensedUsers=""
for obj in "${obj_arr[@]}"
do
	value_arr=(${obj//:/ })
	for i in "${!value_arr[@]}"
	do
		if [[ "${value_arr[$i]}" = '"maximumNumberOfUsers"' ]] ; then
			counter=`expr $i+1`;
			(( maxLicensedUsers=value_arr[$counter] ));
		fi
		if [[ "${value_arr[$i]}" = '{"currentNumberOfUsers"' ]]; then
			index=${i}+1;
			echo "S.No.,FreeLicenses"
			(( licensedUsers=maxLicensedUsers - value_arr[$index] ));
			echo "1,${licensedUsers}"
			exit
		fi
	done
done
#current_number_of_users=`echo $json_data | awk '{split($0,a,",") for (x in a){print x}}'`
#| awk -F ',' '{print $1}'`
#echo $current_number_of_users

