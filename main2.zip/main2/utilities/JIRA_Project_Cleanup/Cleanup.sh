#!/bin/bash

###
###     java_home = ~goyahii/jdks/*
###     jira_cli = /home/goyahii/atlassian-cli-2.0.0
###	compatoble for JIRA version 5.2.10
###

CWD=`pwd`
echo "Current Working Directory = $CWD"

## setup cli
echo "Setting up atlassian CLI for running this utility"
wget --no-check-certificate https://artifactory-1.dts.fm.rbsgrp.net/artifactory/simple/dts-ext-local/com/atlassian/atlassian-cli-7.1.0-distribution.zip
unzip atlassian-cli-7.1.0-distribution.zip 



#set env
#JAVA_HOME="/home/goyahii/jdks/jdk1.8.0_31"
#PATH="$JAVA_HOME/bin:$PATH"

#CCLI="/home/goyahii/atlassian-cli-2.0.0/confluence.sh"
#CCLI="$CWD/atlassian-cli-3.9.0/confluence.sh"
#CSERVER="http://confluence.dts.fm.rbsgrp.net"
JCLI="$CWD/atlassian-cli-7.1.0/jira.sh"
#curl --request DELETE -v -u techuser:password -k --url "http://vmmdtsa15p.server.rbsgrp.net:8070/rest/api/2/project/CBNAP" 
## Change server url below based on project list
#JSERVER_1="https://jira.dts.fm.rbsgrp.net"

JIRA_PROJECT_DETAILS="$CWD/JIRA_Project_Cleanup/Project.details"
#SPACE_DETAILS="$CWD/Confluence_Space_Cleanup/Space.details"
#SPACE_DETAILS="/home/goyahii/Confluence_Space_Cleanup/Space.details"

#test list
#SPACE_KEY="$CWD/Confluence_Space_Cleanup/spacelist.spacekey.him"
#original list
PROJECT_KEY="$CWD/JIRA_Project_Cleanup/projectlist.projectkey.him"

echo "CURRENT ENV VARIABLES ---------------------------------"
env
echo "---------------------------------------------------------"

## setting user credentials
echo "setting up svc user credentials for deletion privileges"
. /opt/app/dts/teamcity/userpass.temp

TLIST=`wc -l ${PROJECT_KEY}`
echo "Total number of JIRA Projects to be deleted = $TLIST"


#rm -v ${JIRA_PROJECT_DETAILS}
echo "Generating project details in csv format ... "
i=1
while read LINE
do
PKEY=`echo "$LINE"|cut -d, -f1`
SURL=`echo "$LINE"|cut -d, -f2`
echo "PROJECT_KEY = $PKEY"
echo "Server_URL = $SURL"
echo "Deleting Project $PKEY from $SURL"
#$JCLI --action deleteProject --project "$PKEY" --server "$SURL" --user "$CUSER" --password "$CPASS"
echo "curl --request DELETE -v -u $CUSER:$CPASS -k --url $SURL/rest/api/2/project/$PKEY"
curl --request DELETE -v -u "$CUSER:$CPASS" -k --url "$SURL/rest/api/2/project/$PKEY"
#$JCLI --action deleteProject --project "$PKEY" --server "$SURL" --user "$CUSER" --password "$CPASS"
#echo "$JCLI --simulate --action deleteProject --project "$LINE" --server $CSERVER --user $CUSER --password $CPASS"
echo "Status : $i / $TLIST"
i=$(($i+1))
echo "============================="
done < ${PROJECT_KEY}


##remove cli
echo "Cleaning up CLI setup done for running this utility"
rm -v atlassian-cli-7.1.0-distribution.zip
rm -rf atlassian-cli-7.1.0-distribution




