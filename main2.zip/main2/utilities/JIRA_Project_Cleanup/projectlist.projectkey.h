CBCC,http://vmmdtsa15p.server.rbsgrp.net:8070
CBNAP,http://vmmdtsa15p.server.rbsgrp.net:8070
CBIN,http://vmmdtsa15p.server.rbsgrp.net:8070