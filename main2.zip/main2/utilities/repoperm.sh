#!/bin/bash
# Get repository permissions

LOCATIONS=/dts_data0/ToolsConfiguration/SVN/cluster/svnbc/apache/conf/dts_svn_locations.conf

REPOSEARCH=`grep -w "Location /$1>" $LOCATIONS`
EMPTY=""


if [ "$REPOSEARCH" != "$EMPTY" ] ; then
	AUTHZFILE=`grep "/$1>" -A 18 $LOCATIONS|grep CrowdAuthzSVNAccessFile|gawk '{print $3}'`
SVNPath=`grep "/$1>" -A 18 $LOCATIONS|grep SVNPath|awk -F"SVNPath " '{print $2}'`
echo -e "\t\t\n\n$AUTHZFILE\n\n"
echo -e "\t\t\n\n$SVNPath\n\n"
cat $AUTHZFILE
fi