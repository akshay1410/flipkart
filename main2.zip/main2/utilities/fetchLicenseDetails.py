#!/usr/bin/python

## Created By - Amit Khurana
## Created On - 11-Jan-2017

## The purpose of this script to fetch licenses from all DES Tools and store it in a text file.
## This script takes input a txt file which has the list of tools and their URL.

import csv
import sys
import pprint
import urllib2
import base64
import json
import StringIO

if len (sys.argv) != 3 :
    print "Usage: python fetchLicenseDetails.py <username> <password> "
    sys.exit (1)

username = str(sys.argv[1])
password = str(sys.argv[2])

f = open('/dts_data0/Scripts/Monitoring/desToolAppsList.csv', 'rb')
reader = csv.reader(f)
rownum = 0
colnum = 0
userCount=0
#licenseList = []
jiraServiceDeskName=""
jiraServiceDeskTotalLicenses=""
jiraServiceDeskRemainingLicenses=""
jiraServiceDeskExpiresOn=""
jiraSoftwareName=""
jiraSoftwareTotalLicenses=""
jiraSoftwareRemainingLicenses=""
jiraSoftwareExpiresOn=""
bitbucketName=""
bitbucketTotalLicenses=""
bitbucketRemainingLicenses=""
bitbucketExpiresOn=""


def getRequest(username,password,url):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
        req.add_header("Authorization", "Basic %s" % base64string)
        req.get_method = lambda: 'GET'
        return req


response = object()
try:
        print "DESToolsApp, TotalLicenses, FreeLicenses, DaysRemaining/Expiring On"
        for row in reader:
                appName = row[0].lower()
                if appName == "jira":
                        url = row[2].lower() + "/rest/api/2/applicationrole"
                        req = getRequest(username,password,url)
                        try:
                                jiraServiceDeskName=""
                                jiraServiceDeskTotalLicenses=""
                                jiraServiceDeskRemainingLicenses=""
                                jiraSoftwareName=""
                                jiraSoftwareTotalLicenses=""
                                jiraSoftwareRemainingLicenses=""
                                response = urllib2.urlopen(req)
                                data = json.load(response)
                                for i in data:
                                        if i["key"] == "jira-servicedesk":
                                                #licenseList.append(str(i["name"]))
                                                #licenseList.append(str(i["numberOfSeats"]))
                                                #licenseList.append(str(i["remainingSeats"]))
                                                jiraServiceDeskName = i["name"]
                                                jiraServiceDeskTotalLicenses = i["numberOfSeats"]
                                                jiraServiceDeskRemainingLicenses = i["remainingSeats"]
                                                url = row[2].lower() + "/rest/plugins/applications/1.0/installed/jira-servicedesk/license"
                                                req = getRequest(username,password,url)
                                                response = urllib2.urlopen(req)
                                                data = json.load(response)
                                                jiraServiceDeskExpiresOn = str(data["expiryDateString"])
                                                #licenseList.append(str(data["expiryDateString"]))
                                        if i["key"] == "jira-software":
                                                #licenseList.append(str(i["name"]))
                                                #licenseList.append(i["numberOfSeats"])
                                                #licenseList.append(i["remainingSeats"])
                                                jiraSoftwareName = str(i["name"])
                                                if i["numberOfSeats"] == -1:
                                                        #licenseList.append("Unlimited")
                                                        jiraSoftwareTotalLicenses="Unlimited"
                                                else:
                                                        #licenseList.append(str(i["numberOfSeats"]))
                                                        jiraSoftwareTotalLicenses=i["numberOfSeats"]
                                                if i["remainingSeats"] == -1:
                                                        #licenseList.append(str(i["userCount"]))
                                                        jiraSoftwareRemainingLicenses=i["userCount"]
                                                else:
                                                        #licenseList.append(str(i["remainingSeats"]))
                                                        jiraSoftwareRemainingLicenses=i["remainingSeats"]
                                                url = row[2].lower() + "/rest/plugins/applications/1.0/installed/jira-software/license"
                                                req = getRequest(username,password,url)
                                                data = json.load(response)
                                                #licenseList.append(str(data["expiryDateString"]))
                                                jiraSotwareExpiresOn = str(data["expiryDateString"])

                                print jiraServiceDeskName+',',str(jiraServiceDeskTotalLicenses)+',',str(jiraServiceDeskRemainingLicenses)+',',jiraServiceDeskExpiresOn
                                print jiraSoftwareName+',',str(jiraSoftwareTotalLicenses)+',',str(jiraSoftwareRemainingLicenses)+',',jiraSotwareExpiresOn
                        except urllib2.URLError, err:
                                print(err.reason)
                        finally:
                                response.close()

                elif appName == "bitbucket":
                        try:
                                url = row[2].lower() + "/rest/api/1.0/admin/license"
                                req = getRequest(username,password,url)
                                response = urllib2.urlopen(req)
                                data = json.load(response)
                                bitbucketExpiresOn = data["numberOfDaysBeforeExpiry"]
                                bitbucketTotalLicenses = data["maximumNumberOfUsers"]
                                bitbucketUsedLicenses = data["status"]["currentNumberOfUsers"]
                                bitbucketRemainingLicenses = int(bitbucketTotalLicenses) - int(bitbucketUsedLicenses)
                                print "Bitbucket"+',',str(bitbucketTotalLicenses)+',',str(bitbucketRemainingLicenses)+',',bitbucketExpiresOn
                        except urllib2.URLError, err:
                                print(err.reason)
                        finally:
                                response.close()
                elif appName == "confluence":
                        try:
                                url = row[2].lower() + "/rest/license/1.0/license/maxUsers"
                                req = getRequest(username,password,url)
                                response = urllib2.urlopen(req)
                                data = json.load(response)
                                confluenceTotalLicenses = data["count"]
                                if int(confluenceTotalLicenses) == 2147483647:
                                        confluenceTotalLicenses = "Unlimited"
                                url = row[2].lower() + "/rest/license/1.0/license/remainingSeats"
                                req = getRequest(username,password,url)
                                response = urllib2.urlopen(req)
                                data = json.load(response)
                                confluenceRemainingLicenses = data["count"]
                                if int(confluenceRemainingLicenses) == 2147483647:
                                        confluenceRemainingLicenses = "Unlimited"
                                ##Expiry Date is hardcoded as of now. It needs to impemented via API
                                print "Confluence"+',',str(confluenceTotalLicenses)+',',str(confluenceRemainingLicenses)+',',"16 days and 7 hours"

                        except urllib2.URLError, err:
                                print(err.reason)
                        finally:
                                response.close()
                                
        rownum += 1

finally:
    f.close()
    #logFile.close()