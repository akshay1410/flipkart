#!/usr/bin/python

## Created By - Amit Khurana
## Created On - 15-Feb-2018


import csv
import sys
import pprint
import urllib
import urllib2
import httplib
import base64
import json
import StringIO
#from urllib.parse import quote
import urlparse

username = 'khuraaa'
password = "Avika@2012"

if len (sys.argv) != 3 :
    print "Usage: ./fecru.py <username> <password> "
    sys.exit (1)

username = str(sys.argv[1])
password = str(sys.argv[2])

def getRequest(username,password,url):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
        req.add_header("Authorization", "Basic %s" % base64string)
        req.get_method = lambda: 'GET'
        return req

def createProject(username,password,params):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        conn = httplib.HTTPConnection("delmw50084:8060")
        conn.set_debuglevel(1)
        headers = {"Authorization": "Basic %s" % base64string, "Content-Type": "application/json", "Accept": "application/json"}
        #data = urllib.urlencode(params)
        #request = urllib2.Request("http://delmw50084:8060", data, headers)
        #response = urllib2.urlopen(request,data)
        conn.request("POST", "/rest-service-fecru/admin/projects", json.dumps(params), headers)
        response = conn.getresponse()
        conn.close()
        return response

def getPermissionScheme(username,password,params):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        handler = urllib2.HTTPHandler(debuglevel=1)
        opener = urllib2.build_opener(handler)
        urllib2.install_opener(opener)
        url = "http://delmw50084:8060/rest-service-fecru/admin/permission-schemes/" + urllib.quote(params)
        req = urllib2.Request(url, "", {'Content-Type': 'application/json', "Accept": "application/json", "Authorization": "Basic %s" % base64string})
        req.get_method = lambda: 'GET'
        response = urllib2.urlopen(req)
        data = json.load(response)
        return response

def getAllPermissionSchemes(username,password):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        handler = urllib2.HTTPHandler(debuglevel=1)
        opener = urllib2.build_opener(handler)
        urllib2.install_opener(opener)
        url = "http://delmw50084:8060/rest-service-fecru/admin/permission-schemes"
        req = urllib2.Request(url, "", {'Content-Type': 'application/json', "Accept": "application/json", "Authorization": "Basic %s" % base64string})
        req.get_method = lambda: 'GET'
        response = urllib2.urlopen(req)
        data = json.load(response)
        return response

def createPermissionScheme(username,password,params):
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        conn = httplib.HTTPConnection("delmw50084:8060")
        conn.set_debuglevel(1)
        parameters=urllib.urlencode(params)
        headers={"Authorization": "Basic %s" % base64string, "Content-Type": "application/json"}
        conn.request("POST", "/rest-service-fecru/admin/permission-schemes", json.dumps(params),headers)
        response = conn.getresponse()
        data=response.read()
        conn.close()
        return data

response = object()
try:
        proj_list_url = "http://lonrs11775:8060/rest-service-fecru/admin/projects"
        req = getRequest(username,password, proj_list_url)
        response = urllib2.urlopen(req)
        proj_json = json.load(response)
        proj_list = proj_json["values"]
        for proj in proj_list:
                proj_key = proj["key"]
                if proj_key == "CRU-ARE":
                        proj_details_url = "http://lonrs11775:8060/rest-service-fecru/admin/projects/" + proj_key
                        req = getRequest(username,password,proj_details_url)
                        response = urllib2.urlopen(req)
                        proj_details = json.load(response)
                        proj_perm_scheme = proj["permissionSchemeName"]
                        try:
                                response = getPermissionScheme(username,"password",proj_perm_scheme)
                        except urllib2.HTTPError as err:
                                if err.code == 404:
                                        perm = {"name": proj_perm_scheme}
                                        response = createPermissionScheme(username,"password", perm)
                                        print data
                        #else:
                        #       permScheme = json.load(response)
                        #       permSchemeName = permScheme["name"]

                        #print "Creating project with key in Amit Localhost - " + proj_key
                        #target_url = "/rest-service-fecru/admin/projects"
                        #response = createProject(username,"password", proj_details)
                        #print response.status, response.reason
                else:
                        continue

except (httplib.HTTPException,urllib2.HTTPError) as err:
        print err
        #content = err.read()
        #reason = err.reason()
        #print reason + ": " + content
finally:
        exit()
        req.close()
    #logFile.close()
