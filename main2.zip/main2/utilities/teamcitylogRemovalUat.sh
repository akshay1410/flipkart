#!/bin/bash

LOGSLOCATION=/opt/app/dts/teamcity/v9.1.7/TeamCity/logs/
ApacheLogLocation=/opt/app/dts/teamcity/ecomm/Web/servers/teamcity/logs/
MAVENARTIFACTS=/opt/app/dts/maven/repository/rs/com/rbs/

echo "Logs Location:$LOGSLOCATION"
echo "Logs Location:$ApacheLogLocation"
echo "Logs Location:$MAVENARTIFACTS"

sshRemoveLogsFunction()
{
echo " ********Preparing to ssh to lonrs11994*******"
ssh proddts@lonrs11994 << EOF
export LOGSLOCATION=$LOGSLOCATION
find $LOGSLOCATION -mtime -7 -exec ls -lrt {} \;
export ApacheLogLocation=$ApacheLogLocation
find $ApacheLogLocation -mtime -7 -exec ls -lrt {} \;
export MAVENARTIFACTS=$MAVENARTIFACTS
find $MAVENARTIFACTS -mtime -7 -type f \( -name "*SNAPSHOT*" -o -name "*RELEASE*" \) -exec ls -lrt {} \;
EOF

echo "Logs removal complete on lonrs11994"


}

sshRemoveLogsFunction