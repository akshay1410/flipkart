#!/bin/bash
###	Pre-requisites:
### 	1) To run this script, "xmllint: using libxml version 20626" must be installed in linux system
###		2) Script is compatible with teamcity 2019.1 and v9.1.7
###		3) Compatible with curl 7.29.0+	
### This script does following things:
###     1) get default vcs polling interval from Teamcity UI's "Administrators -> Global Settings - > Default VCS changes check interval". Default is 1800 secs
###		2) get all vcs-roots
###     3) Read modificationCheckInterval for all vcs roots except explicitly excluded vcs roots
###	    	a) if modificationCheckInterval is less than defaultModificationCheckInterval - then reset to default
###			b) else skip
###		4) end
###
### Written by: europa\agrawgb

CWD=`pwd`

### Inputs
# Teamcity URL. Example: https://localhost:8080
tcURL=$1
username=$2
password=$3
# OPTIONAL: VCS root ids, separated by comma. Example: vcsRoot1,vcsRoot2
excludedVcsRootIds=$4
# Default defaultModificationCheckInterval is 1800 sec
defaultModificationCheckInterval=1800

# Validate the script's input
if [[ $# -lt 3 ]] ; then
    echo "usage: {tcURL: Teamcity URL. Example: http://localhost:8080} {username: Teamcity username} {password: Username's password} {OPTIONAL:: excludedVcsRootIds: List of excluded VCS root ids , separated by comma without any space}"
    exit 1
fi

echo "Following are the inputs provided:"
echo "tcURL: $tcURL"
echo "excludedVcsRootIds: $excludedVcsRootIds"
echo "defaultModificationCheckInterval: $defaultModificationCheckInterval"

ALL_VCS_ROOTS="$CWD/all-vcs-roots-$(date +'%d%m%Y%T').input"

### Get all vcs roots
fetchCount=1000
for ((i=0; ; i+=$fetchCount)); do
	absoluteURL="$tcURL/httpAuth/app/rest/vcs-roots?locator=start:$i,count:$fetchCount"
    contents=$(curl --insecure --silent -u $username:$password -H "Content-Type: application/xml" $absoluteURL)
	echo "$contents" > tmp-vcs-root-$i.xml
	vcsCount=$(echo "cat //vcs-roots/@count" | xmllint --shell tmp-vcs-root-$i.xml | grep count | sed 's/[^0-9]*//g')
	echo "index $i:: Request: $absoluteURL :: Total vcs count: $vcsCount"
	getAllVcs=$(echo "cat //vcs-root/@id" | xmllint --shell tmp-vcs-root-$i.xml | grep id | cut -d \" -f2)
	echo "$getAllVcs" >> $ALL_VCS_ROOTS
	if [[ $vcsCount -eq 0 ]] ; then
		break;
	fi
done

### Cleanup of intermediate files
rm -r tmp-vcs-root-*.xml

### Read all VCS root and update the default check interval
FILE_DATA="$ALL_VCS_ROOTS"

TLIST=`cat ${FILE_DATA} | wc -l`
echo "Total number of VCS root are = $TLIST"

### excludedVcsRootIds to array conversion
OIFS=$IFS
IFS=','
arrayOfExcludedVcsRootIds=$excludedVcsRootIds
echo "arrayOfExcludedVcsRootIds:: $arrayOfExcludedVcsRootIds"

echo "Iterating over all vcs roots to update the check interval..."
i=1
while read vcsRootId
	do
		# Continue next if vcsRootId is empty
		if [[ -z "${vcsRootId// }" ]]; then
			continue
		fi
	
		if [[ ! "${arrayOfExcludedVcsRootIds[@]}" =~ "${vcsRootId}" ]]; then
			# whatever you want to do when arrayOfExcludedVcsRootIds doesn't contain value
			vcsCheckIntervalURL="$tcURL/httpAuth/app/rest/vcs-roots/id:${vcsRootId}/modificationCheckInterval"
			modificationCheckInterval=$(curl --insecure --silent -k -u $username:$password -H "Content-Type: application/xml" $vcsCheckIntervalURL)
			if [[ $modificationCheckInterval =~ ^[0-9]+$ ]] ; then
				if [[ $modificationCheckInterval -lt $defaultModificationCheckInterval ]] ; then
				echo "$i / $TLIST ::: modificationCheckInterval is $modificationCheckInterval for $vcsCheckIntervalURL"
				updatedResponse=$(curl --insecure --silent -u $username:$password -X PUT -H "Content-Type: text/plain" -d "$defaultModificationCheckInterval" $vcsCheckIntervalURL)
				if [[ "$updatedResponse" =~ ^[0-9]+$ ]]; then
					echo "SUCCESS:: Successfully updated the check interval $modificationCheckInterval to default $updatedResponse"
				else
					echo "FAILED:: Failed updating the check interval. Error: $updatedResponse"
				fi
			fi
			else
				echo "FAILED:: Unable to get modificationCheckInterval for vcsRootId: $vcsRootId. Error: $modificationCheckInterval"
			fi
		fi
		
	i=$(($i+1))
	
done < ${FILE_DATA}

IFS=$OIFS
rm -r $ALL_VCS_ROOTS
echo "Execution is finished. Please refer logs for any warning or error"