#!/bin/bash

	# Teamcity Job will share the instance on which we need to remove the build queue with no compatible agents
	echo "TeamCuity Instance : ${TC_INSTANCE}"

	QLIST_RESTAPI=httpAuth/app/rest/buildQueue
	CREDENTIALS="APP-DTSADMIN:BTVv8MSs"

	# below command will help to fetch the detailed list of the builds which are in queue.
	curl -v -u ${CREDENTIALS} -k --request GET ${TC_INSTANCE}${QLIST_RESTAPI} --header "Content-Type:application/xml"  > buildqueuelist.xml

	#curl -v -u ${CREDENTIALS} --request GET http://lonrs12230.fm.rbsgrp.net:8111/httpAuth/app/rest/buildQueue --header "Content-Type:application/xml"  > queuelist.xml
	#curl -v -u ${CREDENTIALS} --request GET http://lonrs12230.fm.rbsgrp.net:8111/httpAuth/app/rest/buildQueue --header "Content-Type:application/xml" > filelist.txt

	# With this script I will fetch the ids of the builds 
	grep -o '<build id="[^"]*"' buildqueuelist.xml  | sed 's\"\ \g' | awk '{print $NF}' > id_list.txt

	echo " Listing all the ids"
	cat id_list.txt

for line in `cat id_list.txt`;
do
echo $line ;

	curl -v -u ${CREDENTIALS} -k --request GET ${TC_INSTANCE}${QLIST_RESTAPI}/id:${line} --header "Content-Type:application/xml" > find_detail.txt
	#curl -v -u ${CREDENTIALS} --request GET http://lonrs12230.fm.rbsgrp.net:8111/httpAuth/app/rest/buildQueue/id:${line} --header "Content-Type:application/xml" > find_detail.txt

	# check weather the build has no compatible agent in the details ""
	cat find_detail.txt | grep "no compatible agents"

	if [ $? -eq 0 ]
	then
		echo " "
		echo "${TC_INSTANCE}${QLIST_RESTAPI}/id:$line"
		#curl -v -u ${CREDENTIALS} --request DELETE http://lonrs12230.fm.rbsgrp.net:8111/httpAuth/app/rest/buildQueue/id:${line} --header "Content-Type:application/xml"
		#curl -v -u ${CREDENTIALS} -k --request DELETE ${TC_INSTANCE}${QLIST_RESTAPI}/id:${line} --header "Content-Type:application/xml"
		curl -v -u ${CREDENTIALS} -k --request GET ${TC_INSTANCE}${QLIST_RESTAPI}/id:${line} --header "Content-Type:application/xml"
		
		#sleep 2
	fi

done
