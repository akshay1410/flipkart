DES Tools Geneos Monitoring
===================================

Geneos is the monitoring tool which used to monitor DES Tools application in real time. Monitoring is consists of three main components below:
1.	ActiveConsole – To monitor the trends, graph etc. We need to install it in our desktop.
2.	Probes – It is a agent which is installed on each application server. It is used to collect all configured metrics for the server.
3.	Gateways – It is a bridge between ActiveConsole & Probes. Generally, It collects data from Probe and show metrics in ActiveConsole.


## Gateways configuration files

### To configure NetProbe and Managed Entity - 
Always use 03.mes.include.xml (Netprobe and Managed entity should be defined under this Includes only)

### To configure Sampler, Rules, Types etc - 
Always use <APP><REGION><ENV>.global.include.xml, For eg. dts-uk-uat.global.include.xml

For More Info: https://confluence.dts.fm.rbsgrp.net/display/BIARCH/Gateways+Include+files

## Monitoring configuration standards
Refer: https://confluence.dts.fm.rbsgrp.net/display/DVLSERV/Application+Monitoring+Remediation