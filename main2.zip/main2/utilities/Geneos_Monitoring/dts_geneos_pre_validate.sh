#!/bin/bash
count1=`egrep -ic 'sampler name="webmon-test"' ${_SETUP}`
if [[ $count1 -eq 0 ]]
then
echo "<issue>"
echo "<severity>Error</severity>"
echo "<path>/gateway/operatingEnvironment</path>"
echo "<message>Sampler "webmon-test" shouldnt be disable, please enable this sampler</message>"
echo "</issue>"
fi

count2=`egrep -ic  'rule name="rule-testing"' ${_SETUP}`
if [[ $count2 -eq 1 ]]
then
echo "<issue>"
echo "<severity>Error</severity>"
echo "<path>/gateway/operatingEnvironment</path>"
echo "<message>Please donot create any rule of name "rule-testing". Please delete this rule</message>"
echo "</issue>"
fi