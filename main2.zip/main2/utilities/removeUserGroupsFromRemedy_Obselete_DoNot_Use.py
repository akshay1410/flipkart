#!/usr/bin/python


## Created By - Amit Khurana
## Created On - 14-Jan-2016
## Modified On - 18-Jan-2016
## Deactivate Users from Crowd.
## Sample file is a CSV file in the checked in format file - SampleRemedyData.csv:
## This script should always be run manually and not as automated job. Because currently this needs application "jira_ak" to be configured in CROWD
## to setup directories properly in order to remove from a specific domain only.


import csv
import sys
import pprint
import urllib2
import base64


username = 'jira_ak'
#username = 'jira_5_2_10'
password = "password"
taskTitle = "other system access request"
system = "IUER / Infrastructure requests"
startString = "Please remove Account "
fromGroupString = " from DTS Groups "
endOfGroupString = "  ------------------ "

f = open('SampleRemedyData.csv', 'rb')
reader = csv.reader(f)
#logFile = open('remedyLog.txt', "w")
rownum = 0

response = object()
try:
	for row in reader:
		if rownum == 0:
			header = row
		else:
			if (taskTitle == row[5] and system == row[6]) :
				taskDetails = row[7]
				ticketid = row[0]
				user = taskDetails[taskDetails.find(startString)+len(startString):taskDetails.rfind(fromGroupString)]
				groups = taskDetails[taskDetails.find(user+fromGroupString)+len(user+fromGroupString):taskDetails.rfind(endOfGroupString)]
				group_arr = groups.split(",")
				for gp in group_arr:
					if '-PM' in gp:
						gp=gp.replace('-PM','-project-managers')
					#url = "https://uatcrowd-dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user/group/direct?username=%s&groupname=%s"  % (user.strip(), gp.strip())
					url = "https://crowd-3.dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user/group/direct?username=%s&groupname=%s"  % (user.strip(), gp.strip())
					base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
					req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
					req.add_header("Authorization", "Basic %s" % base64string)
					req.get_method = lambda: 'DELETE'
					try:
						response = urllib2.urlopen(req)
						if not response or not response.read():
							print "Status:204, Request successfully completed. " + user + " removed from  " + gp + " successfully."
					except urllib2.HTTPError, error:
						content = error.read()
						#print content
						if not content:
							print "Status:204, Request successfully completed. " + user + " removed from  " + gp + " successfully."
						else:
							print "TicketId:%s, User:%s, Group:%s, Response:%s\n" % (ticketid, user, gp, content)
						pass

		rownum += 1
finally:
	f.close()
	#logFile.close()	

