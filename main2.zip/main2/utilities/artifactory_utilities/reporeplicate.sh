#!/bin/bash +x

REMOTE_URL="https://artifactory.server.rbsgrp.net/artifactory"
ARTIFACTORY_URL="https://artifactory-1.dts.fm.rbsgrp.net/artifactory"

#curl -k  ${ARTIFACTORY_URL}/api/repositories > tempfile.txt
#List of the Repos provided in the file

#cat tempfile.txt | grep key | awk '{print $NF}' | sed "s/,//g" | sed "s/\"//g" > repolist.txt

## below code is to get details for repo replication
echo "REPO DETAIL,REPLICATICATION DETAIL" > finalrepldetails.txt
for REPO in `cat repolist.txt`
do
curl -u app-dtsadmin:BTVv8MSs -k ${ARTIFACTORY_URL}/api/replications/${REPO} > replication_status.txt
cat replication_status.txt | grep "404"
if [ $? -eq 0 ]
then
        echo "${REPO},NO REPLICATION SET" >> finalrepldetails.txt
        REPO_DEST_URL="${REMOTE_URL}/${REPO}/"

        curl -u app-dtsadmin:BTVv8MSs -k ${ARTIFACTORY_URL}/api/replications/${REPO}   -H "Accept: application/json"   -H "Content-Type: application/json"  -X PUT -d '{  "url" : "'$REPO_DEST_URL'",   "socketTimeoutMillis" : "15000",   "username" : "app-dtsadmin",  "password" : "BTVv8MSs", "enableEventReplication" : "true",  "syncStatistics" : "true",  "enabled" : "true",  "cronExp" : "0 50 04 ? * *",  "syncDeletes" : "true",  "syncProperties" :  "true",  "repoKey" : "'$REPO'"  }'
        echo "${REPO},ENABLED" >> finalrepldetails.txt
	curl -u app-dtsadmin:BTVv8MSs -k ${ARTIFACTORY_URL}/api/replications/${REPO}
else
        echo "${REPO},REPLICATION ALREADY CONFIGURED" >> finalrepldetails.txt
	curl -u app-dtsadmin:BTVv8MSs -k ${ARTIFACTORY_URL}/api/replications/${REPO}
fi


####### below code is for setting the replication
#REPO_DEST_URL="${REMOTE_URL}/${REPO}/"


#curl -u app-dtsadmin:BTVv8MSs -k ${ARTIFACTORY_URL}/api/replications/${REPO}   -H "Accept: application/json"   -H "Content-Type: application/json"  -X PUT -d '{  "url" : "'$REPO_DEST_URL'",   "socketTimeoutMillis" : "15000",   "username" : "app-dtsadmin",  "password" : "BTVv8MSs", "enableEventReplication" : "true",  "syncStatistics" : "true",  "enabled" : "true",  "cronExp" : "0 20 04 ? * *",  "syncDeletes" : "false",  "syncProperties" :  "true",  "repoKey" : "'$REPO'"  }'



done

echo "#######################################"
echo "#######################################"
echo "#######################################"
echo " FINAL Replication Status "
cat finalrepldetails.txt
