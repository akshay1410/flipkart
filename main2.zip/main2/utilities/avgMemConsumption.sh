#!/bin/sh

## Created By - Amit Khurana
## Created On - 21-Feb-2018
## Monitor System Resources and echo results
## This checks for avg mem, swap and paging

SERVER=$1

#echo "Column,Blocking/waiting,Sleeping,Free,Bufferred,Cache,Memory SwappedIn,Memory SwappedOut,CPU Waiting for IO"
#allstats="$(vmstat -S M |tail -1 | tr -s ' ' | cut -d ' '  -f 2,3,5,6,7,8,9,17 | sed s/\ /\,/g)"
echo "Columns,Total,Used,Free,Shared,Buffers,Cached"
allmem="$(free -m | tr -s ' ' | grep Mem | cut -d ' ' -f 2-7 | sed s/\ /\,/g)"
totalRAM="$(free -m | tr -s ' ' | grep Mem | cut -d ' ' -f 2)"
totalUsedRAM="$(free -m | tr -s ' ' | grep Mem | cut -d ' ' -f 3)"
cache="$(free -m | tr -s ' ' | grep Mem | cut -d ' ' -f 7)"
buffer="$(free -m | tr -s ' ' | grep Mem | cut -d ' ' -f 6)"
totalTemp=` expr $cache + $buffer`
actualTotUsedRAM=` expr $totalUsedRAM -  $totalTemp `
actualTotalRAMAvailabe=`expr $totalRAM - $actualTotUsedRAM`
cache="$(free -m | tr -s ' ' | grep 'buffers/cache' | cut -d ' ' -f 3-4 | sed s/\ /\,/g)"
swap="$(free -m | tail -1 | tr -s ' ' | grep Swap | cut -d ' ' -f 2-7 | sed s/\ /\,/g)"
echo "RAM,$totalRAM,$actualTotUsedRAM,$actualTotalRAMAvailabe"
echo "Buffers/Cache,,$cache"
echo "Swap,$swap"