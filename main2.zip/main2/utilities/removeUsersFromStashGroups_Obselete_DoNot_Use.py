#!/usr/bin/python

## Created By - Amit Khurana
## Created On - 21-Jan-2016

## The purpose of this script to remove associations of user and its groups in crowd. This script will remove all 
## groups assocations related to a user.
## This script takes input a csv list of userids and fetch the groups from crowd and remove them.

import csv
import sys
import pprint
import urllib2
import base64
import xml.sax
import xml.dom
from xml.dom import minidom
import StringIO

username = 'jira_ak'
password = "password"

f = open('CROWDUsersToDeactvivate.csv', 'rb')
reader = csv.reader(f)
#logFile = open('groupsRemovalLog.txt', "w")
rownum = 0
groupnum = 0

response = object()
try:
    for row in reader:
		racfid = row[0].lower()
		url = "https://uatcrowd-dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user/group/direct?username=%s"  % (racfid.strip())
		base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
		base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
		req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
		req.add_header("Authorization", "Basic %s" % base64string)
		req.get_method = lambda: 'GET'
		try:
			response = urllib2.urlopen(req)
			content = response.read()
			xmldoc = minidom.parse(StringIO.StringIO(content))
			for element in xmldoc.getElementsByTagName('group'):
				attr = element.attributes["name"]
				if attr:
					#print attr.name + " " + attr.value
					if "stash" in attr.value.strip().lower():
						print "Group " + attr.value + " found for user " + racfid + ". "
						url = "https://uatcrowd-dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user/group/direct?username=%s&groupname=%s"  % (racfid.strip(), attr.value.strip().lower())
						base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
						base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
						req = urllib2.Request(url, "", {'Content-Type': 'application/json'})
						req.add_header("Authorization", "Basic %s" % base64string)
						req.get_method = lambda: 'DELETE'
						try:
							response = urllib2.urlopen(req)
							print "Response for: " +  racfid + " " +  attr.value + " - " + response.read()
						except urllib2.HTTPError, error:
							content = error.read()
						print "Response for: " +  racfid + " " +  attr.value + " - " + content
				else:
					content = "No groups attached to" + racfid.strip()
				groupnum += 1
		except urllib2.HTTPError, error:
			content = error.read()
		print "Response For racfid: " + racfid.strip() + " " + content
		rownum += 1
finally:
    f.close()
    #logFile.close()

