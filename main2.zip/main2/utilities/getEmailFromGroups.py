#!/usr/bin/python

##Created By - Amit Khurana
## Created On - 15-Feb-2018

import os
import csv
import sys
import pprint
import urllib
import urllib2
import httplib
import base64
import xml.sax
import xml.dom
from xml.dom import minidom
import StringIO
#from urllib.parse import quote
import urlparse


def getRequest(url):
	username="fisheye_6"
	password="password"
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        base64string = base64.encodestring('%s:%s' % (username,password)).replace('\n', '')
        req = urllib2.Request(url, "", {'Content-Type': 'application/xml'})
        req.add_header("Authorization", "Basic %s" % base64string)
        req.get_method = lambda: 'GET'
        return req

def getEmail(content):
	xmldoc = minidom.parse(StringIO.StringIO(content))
	emailString=""
	for element in xmldoc.getElementsByTagName('email'):
		emailString = emailString + element.firstChild.data.encode("utf-8") + ";"
		#print element.firstChild.data
	return emailString
	


if len (sys.argv) != 2 :
    print "Usage: ./fecru.py <file containing group names>"
    sys.exit (1)

csvfile = "emails.csv"

groupList = str(sys.argv[1])

try:
	emails = open(csvfile, "a")	
	with open(groupList, 'rb') as f:
		for line in f:
			crowdUrl = "https://crowd-3.dts.fm.rbsgrp.net/crowd/rest/usermanagement/latest/group/user/nested?groupname="+ line.rstrip(os.linesep)  + "&start-index=0&max-results=500&expand=user"
			print crowdUrl
			req=getRequest(crowdUrl)
		
	        	response = urllib2.urlopen(req)
			data=response.read()
			emaillst = getEmail(data)
			emails.write(emaillst)
except (httplib.HTTPException,urllib2.HTTPError) as err:
        print err.reason
	print err.code
finally:
	emails.close()
	f.close()


		
