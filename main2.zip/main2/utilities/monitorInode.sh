#!/bin/bash

#### Author: Amit Khurana
#### Date: 14/Sep/2017
#### This script check iNode in percentage and returns the value for a given folder path

usage()
{
  echo "Usage: $0 <Is_Local_Filer>"
  exit 1
}

##### MAIN PROGRAM

####    Check arguments and display usage message
if [ $# != 1 ] || [ $1 == "-h" ]; then
  usage
fi

#DIRECTORY_TO_CHECK=$1
IS_LOCAL_FILER=$1
LOCAL_DISK="/opt/app/dts"
NAS_LOCATIONS="/data/dtsjiraprd,/data/dtsconfprd"
INODE_USE_PERC=""

if [ "$IS_LOCAL_FILER" == "y" ] || [ "$IS_LOCAL_FILER" == "Y" ]
then
        echo "Inodes,Percent"
        INODE_USE_PERC="`df -i ${LOCAL_DISK}|  tail -1  | awk '{print $(NF-1)}' | sed 's/%//'`"
        echo "INodes_Use_Perc,${INODE_USE_PERC}"
fi
if [ "$IS_LOCAL_FILER" == "n" ] || [ "$IS_LOCAL_FILER" == "N" ]
then
        if [ -f  "/dts_data0/Scripts/Monitoring/folderList.txt"  ]
        then
                echo "Inodes,Percent" > iNodeDetails.txt
                for line in `cat /dts_data0/Scripts/Monitoring/folderList.txt`
                do
                        INODE_USE_PERC=`df -i ${line}| tail -1  | awk '{print $(NF-1)}' | sed 's/%//'`
                        echo "${line},${INODE_USE_PERC}" >> iNodeDetails.txt
                done
                cat iNodeDetails.txt
        else
                echo "Source file with folder list not found"
                exit 1
        fi
fi