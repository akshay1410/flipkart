#!/bin/bash
export srcname=$1
export archivetime=$2
export deletiontime=$3
export filename=`echo $4|sed "s/:/ /g"`
export archloc=$5
(
echo " Archving Started on $(date) "
if [ -z $srcname ] || [ -z $archivetime ] || [ -z $deletiontime ] || [ $(echo ${#filename}) -eq 0 ] || [ -z $archloc ]
then
        echo "Please enter the missing argument."
        echo "Usage ./archfiles.sh [Directory Name] [Age (in days) of files to delete]"
        exit 0
else
  for fname in $filename
    do
      for i in $(find $srcname -maxdepth 1 -type f -mtime +$archivetime -name "$fname*")
        do
         cd $srcname
         gzip $i
         mv $i* $archloc/.
        done
#######################Deleting files ########################################################
   cd $archloc
   error=$?
   if [ $error -eq 0 ]
   then
   find $archloc -maxdepth 1 -type f -mtime +$deletiontime -name "$fname*" -exec rm -f {} \;
   else
   exit 0
   fi
    done
fi
echo " Archving Completed on $(date) "
) >>$archloc/archfiles.log 2>&1