#!/bin/bash
<<COMMENT1

--------------------------------------------------------------------------------------
| This script archive file on the basis of parameter mention in the trigcard file:   |
| Description of parameter in trigcard are as below:                                 |
| host|srcname|archivetime|deletiontime|filename1:filename2:filename3|archloc        |
--------------------------------------------------------------------------------------

COMMENT1
export script_home="/opt/app/dts/scripts/housekeeping"
(
cat $script_home/trigcard|awk 'NR>6'|while read line
do
host=`echo $line|awk -F "|" '{print $1}'`
srcname=`echo $line|awk -F "|" '{print $2}'`
archivetime=`echo $line|awk -F "|" '{print $3}'`
deletiontime=`echo $line|awk -F "|" '{print $4}'`
filename=`echo $line|awk -F "|" '{print $5}'`
archloc=`echo $line|awk -F "|" '{print $6}'`
ssh -n proddts@$host "$script_home/archfiles.sh $srcname $archivetime $deletiontime $filename $archloc" 2>/dev/null
error=$?
if [ $error -ne 0 ]
then
echo "Archival Process failed for `date` on $host for location $srcname"
else
echo "Archival Process completed for `date` on $host for location $srcname"
fi
done
)>>$script_home/archtrig.log 2>&1
