#!/bin/bash
# Get repository permissions

LOCATIONS=/dts_data0/ToolsConfiguration/SVN/cluster/svnsh/apache/conf/dts_svn_locations.conf

ALLARG=$1
REPOSEARCH=`grep -w "/$1>" $LOCATIONS`
EMPTY=""
allString="all"
AllString="ALL"

if [ "$ALLARG" = "$allString" ] ||[ "$ALLARG" = "$AllString"  ] ; then

#read -p "Go ahead with clearing cache on all master svn servers  ? (y/n) " RESP
#if [ "$RESP" = "y" ]; then

        echo " Clearing the cache on all master servers"
        CACHELOCATION="/opt/app/dts/Cache/SVN/CrowdAuth*"
        echo " ********Preparing to ssh to lonrs10155*******"
        ssh proddts@lonrs10155 export CACHELOCATION=$CACHELOCATION '; rm -rf $CACHELOCATION; exit;'

        echo " ********Preparing to ssh to lonrs10156*******"
        ssh proddts@lonrs10156 export CACHELOCATION=$CACHELOCATION ';  rm -rf $CACHELOCATION; exit;'

        echo " ********Preparing to ssh to lonrs10157*******"
        ssh proddts@lonrs10157 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'

        echo " ********Preparing to ssh to lonrs10084*******"
        ssh proddts@lonrs10084 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'
        echo " ********Preparing to ssh to lonrs10085*******"
        ssh proddts@lonrs10085 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'

        echo "Cache removal complete"

        exit
#else
#        echo "Come back when you are sure then"
#        exit
#        fi
fi

if [ "$REPOSEARCH" != "$EMPTY" ] ; then
 #grep "/$1>" -A 18 $LOCATIONS|grep -i CrowdCacheLocation
 CACHELOCATION=` grep "/$1>" -A 18 $LOCATIONS|grep -i CrowdCacheLocation|gawk '{print $3}'`
else
echo "Repository does not exist in the svn config file. Please try again.";exit;
fi

echo "Cache Location:$CACHELOCATION"
sshRemoveCacheFunction()
{
#export CACHELOCATION
#echo $CACHELOCATION
#ssh proddts@lonrs10155 <<EOx
#  echo "This is the \$CACHELOCATION"
#exit
#EOx
echo " ********Preparing to ssh to lonrs10155*******"
ssh proddts@lonrs10155 export CACHELOCATION=$CACHELOCATION '; rm -rf $CACHELOCATION; exit;'

echo " ********Preparing to ssh to lonrs10156*******"
echo " ********Preparing to ssh to lonrs10157*******"
ssh proddts@lonrs10157 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'

echo " ********Preparing to ssh to lonrs10084*******"
ssh proddts@lonrs10084 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'
echo " ********Preparing to ssh to lonrs10085*******"
ssh proddts@lonrs10085 export CACHELOCATION=$CACHELOCATION ';rm -rf $CACHELOCATION; exit;'

echo "Cache removal complete"
}


#read -p "Go ahead with clearing the cache at '$CACHELOCATION'  ? (y/n) " RESP
#if [ "$RESP" = "y" ]; then
  sshRemoveCacheFunction
#        else
#  echo "Ok, Come back when you sure then!";
#fi

REPOSEARCH=""
CACHELOCATION=""
