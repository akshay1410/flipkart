#!/bin/bash


## Created By - Amit Khurana
## Created On - 15-Jan-2016
## Modified On - 18-Jan-2016
## Deactivate Users from Crowd.
## Sample file is a CSV file in the following format with no header row:
## racfid,firstname,lastname,email,directory
## This script should always be run manually and not as automated job. Because currently this needs application "jira_ak" to be configured in CROWD
## to setup directories properly in order to remove from a specific domain only.
## This script reads parameter from the command line to activate or deactivate the users.

while IFS=","  read -r f1 f2 f3 f4 f5
do
        #racfid=$(echo $f1 | tr '[:upper:]' '[:lower:]')
        xml="<?xml version='1.0' encoding='UTF-8'?><user name='$f1'><first-name>$f2</first-name><last-name>$f3</last-name><display-name>$f2 $f3</display-name><email>$f4</email><active>false</active></user>"
        xmlPacket=${xml/%$'\r'/}
        if [[ "$f5" == "fm" ]]; then
        	echo "Inside fm"
        	response=$(curl -X PUT --data "$xmlPacket"  https://crowd-3.dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user?username=$f1 -H "Content-Type: application/xml" -u crowd_api_duser_fm:password -k)
        elif [[ "$f5" == "europa" ]]; then
        	echo "Inside europa"
        	response=$(curl -X PUT --data "$xmlPacket"  https://crowd-3.dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user?username=$f1 -H "Content-Type: application/xml" -u crowd_api_duser_europa:password -k)
        elif [[ "$f5" == "gcm" ]]; then
        	echo "Inside gcm"
        	response=$(curl -X PUT --data "$xmlPacket"  https://crowd-3.dts.fm.rbsgrp.net/crowd/rest/usermanagement/1/user?username=$f1 -H "Content-Type: application/xml" -u crowd_api_duser_gcm:password -k)
        fi
        if [[ -z "$response" ]]; then
                echo "User $f1 deactivated successfully" $response
        else
                echo "User $f1: " $response
        fi
done < CROWDUsersToDeactvivate.csv