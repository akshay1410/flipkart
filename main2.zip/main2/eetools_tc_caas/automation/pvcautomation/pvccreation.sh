#!/bin/bash
#set -x
#########################################################################################################
#                       Update values in manifest file                                                  #
#                       Author: Akshay kumar                                                            #
#                       Date: April 14, 2021                                                            #
#########################################################################################################

ns=$1
sc=$2
pvcname="pvcclaim${ns}"

#updating manifest file

sed -i 's/'tempnamespace'/'$ns'/g' automation/pvcautomation/pvctemplate.yml
sed -i 's/'storageclass'/'$sc'/g' automation/pvcautomation/pvctemplate.yml
sed -i 's/'pvcclaimtemplate'/'$pvcname'/g' automation/pvcautomation/pvctemplate.yml

pvccreationstatus=`kubectl apply -f automation/pvcautomation/pvctemplate.yml | awk '{print $2}'`

if [ "$pvccreationstatus" == "created" ] || [ "$pvccreationstatus" == "unchanged" ];
then
    pvcstatus=`kubectl get pvc | grep -i $pvcname | awk '{print $2}'` 
    sleep 15
    if  [ "$pvcstatus" == "Bound" ] ;
        then 
            echo "PVC $pvcname Created and Bound successully"
            
	    rm ~/.kube/config
        rm automation/pvcautomation/pvctemplate.yml
            exit 0
    else
         echo "PVC created but Bound failed"
	 rm ~/.kube/config
     rm automation/pvcautomation/pvctemplate.yml
         exit 1
    fi
else
   echo "PVC creation failed , Please check the inputs and try again"
   rm ~/.kube/config
   rm automation/pvcautomation/pvctemplate.yml
   exit 1
fi
