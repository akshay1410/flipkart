import os
import os.path
from os import path
import xml.etree.ElementTree as ET
import urllib2
import tarfile
import zipfile
import shutil

#Created By - Amit Khurana
#Created On - 05/03/2021
#Description - To download build tools from Artifactory and setup and confiure on NAS filer in CaaS Env

tree = ET.parse('CaaSBuildTools.conf')
root = tree.getroot()

for tool in root.findall('tool'):
    dirPath = tool.find('deployPath').text + "/" + tool.find('name').text + "/" + tool.find('version').text
    if tool.find('setup').text == "skip":
        continue
    elif tool.find('setup').text == "remove":
	if(os.path.exists(dirPath)):
	    shutil.rmtree(dirPath)
            print dirPath + " removed successfully."
	else:
	    print dirPath + " does not exists."
        continue   
	
    if path.exists(dirPath):
        print dirPath + " already exists. Skipping..."
        continue
    os.makedirs(dirPath)
    print "Deployemnt Directory Created: " + dirPath
    filetype = tool.find("filetype").text
    os.chdir(dirPath)
    
    print "Downloading " + tool.find('name').text + " Version " + tool.find('version').text  + "..."
    url = tool.find('downloadPath').text
    req = urllib2.urlopen(url)
    CHUNK_SIZE = 1 << 20
    
    deployPackage = dirPath + "/" + tool.find('name').text + tool.find('version').text + "." + tool.find("filetype").text
    with open(deployPackage, 'wb') as f:
        while True:
            chunk = req.read(CHUNK_SIZE)
            if not chunk:
                break
            f.write(chunk)
    if filetype == "tar.gz":
        tar = tarfile.open(deployPackage, "r:gz")
        tar.extractall(dirPath)
        tar.close()
    elif filetype == "tar":
	tar = tarfile.open(deployPackage, "r:")
	tar.extractall(dirPath)
	tar.close()
    elif filetype == "zip":
        with zipfile.ZipFile(deployPackage, 'r') as zip_ref:
            zip_ref.extractall(dirPath)
    print deployPackage + " successfully installed."
    if os.path.exists(deployPackage):
        os.remove(deployPackage)
