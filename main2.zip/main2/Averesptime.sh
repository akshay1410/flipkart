#!/bin/bash
#set -x
#########################################################################################################
#                       Script for fetching avg reposnse time                                           #
#                       Author: Akshay kumar                                                            #
#                       Date: sept  23, 2020                                                            #
#########################################################################################################

Log_path=$1
Log_file=access.log.`date +%m.%d.%Y`

avg_time_in=`cat $Log_path/$Log_file | tail -10000 | awk 'BEGIN {FS = " "} ; {sum+=$NF} END {print sum / NR}'`
#avg_time_in_sec=$(( avg_time_in / 1000000 ))
echo "Avg_Resp_time_in_sec"
#echo "scale=4; $avg_time_in/1000000" |bc -l
echo "scale=4; $avg_time_in/1000000" |bc -l



