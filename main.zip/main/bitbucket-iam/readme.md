How to execute the Utility.
Clone the code from repohttps://kumaald@stash.dts.fm.rbsgrp.net/scm/dts/bitbucket-iam.git in any bash terminal
vi <Path_to_Utility>/bb-iam/ext/nonstandardgrp.txt
Add the groups which needs migration in the <Path_to_Utility>/bb-iam/ext/nonstandardgrp.txt file.
./bbnonstdgroupmigration.sh <Username> <Password> BitbucketURL:
"usage:  {username: Bitbucket username} {password: Username's password} {BitbucketURL:} "

Utility to  create new  role set in DSP application
How to execute the Utility.

Clone the code from repohttps://kumaald@stash.dts.fm.rbsgrp.net/scm/dts/bitbucket-iam.git in any bash terminal
vi <Path_to_Utility>/bb-dsputil/ext/nonstdgroups.txt
Add the groups which needs migration in the <Path_to_Utility>/bb-iam/ext/nonstdgroups.txt file.
./bbnonstdgroupmigration.sh <Username> <Password> BitbucketURL:
"usage:  {username: Bitbucket username} {password: Username's password} {BitbucketURL:} "
