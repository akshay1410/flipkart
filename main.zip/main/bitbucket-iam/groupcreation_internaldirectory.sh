#/bin/sh!
#!/bin/bash
#set -x
#########################################################################################################
#                       Script for bb group creation in internal directory                              #
#                       Author: Akshay kumar                                                            #
#                       Date: Nov  2, 2020                                                            #
#########################################################################################################

## files creation and initialisation


#Passed arguments handling and assiging them to variables
bitburl=$1
username=APP-DTSADMIN
password=BTVv8MSs
grpprefix=$2

# Validate the script's Arguments
if [[ $# -lt 2 ]] ; then
    echo "Usage:  {BitbucketURL:} {grpprefix} {Username}{password} "
exit 1
fi
# finding the directory id

directoryid=`curl -s -k -u $username:$password $bitburl/rest/dws/1.0/directory/all  -H 'Content-Type: application/json' -H 'Accept: application/json' |  python -mjson.tool | grep -vE 'updatedDate|name|createdDate|isActive|description' | sed 's/{//g' | sed 's/}//g' | sed 's/"//g' | sed 's/\[//g'| sed 's/\]//g' |sed 's/,//g' | sed 's/ //g' | sed '/^$/d' | awk 'NR%2{printf "%s ",$0;next;}1' |sed 's/ /:/g'|grep INTERNAL |awk -F: '{print $2}'`

adminflag=`curl -X POST -s -k -u $username:$password $bitburl/rest/dws/1.0/directory/$directoryid/group/rApp-bitb-$grpprefix-administrators -H 'Content-Type: application/json' -H 'Accept: application/json' |  python -mjson.tool  | grep rApp-bitb-$grpprefix-administrators | awk -F: '{print $2}' |sed 's/"//g' | xargs | awk '{print $6}'`
developerflag=`curl -X POST -s -k -u $username:$password $bitburl/rest/dws/1.0/directory/$directoryid/group/rApp-bitb-$grpprefix-developers -H 'Content-Type: application/json' -H 'Accept: application/json' |  python -mjson.tool  | grep rApp-bitb-$grpprefix-developers | awk -F: '{print $2}' |sed 's/"//g' | xargs | awk '{print $6}'`
userflag=`curl -X POST -s -k -u $username:$password $bitburl/rest/dws/1.0/directory/$directoryid/group/rApp-bitb-$grpprefix-users -H 'Content-Type: application/json' -H 'Accept: application/json' |  python -mjson.tool  | grep rApp-bitb-$grpprefix-users | awk -F: '{print $2}' |sed 's/"//g' | xargs | awk '{print $6}'`

if [ "$adminflag" == "exists" ] && [ "$developerflag" == "exists" ] && [ "$userflag" == "exists" ];
then
echo "Group creation failed : Group with name $grpprefix already exists in directory <Stash Internal Directory>"
exit 1
else
echo "Groups creation success : rApp-bitb-$grpprefix-administrators,rApp-bitb-$grpprefix-developers,rApp-bitb-$grpprefix-users created sucess Stash Internal Directory "
exit 0
fi

