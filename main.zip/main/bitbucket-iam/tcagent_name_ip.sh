#!/bin/bash
#set -x
#########################################################################################################
#                       Script for generating of Server Statistics and logs                             #
#                       Author: Akshay kumar                                                            #
#                       Date: june 30, 2021                                                             #
#########################################################################################################

#rm -rf tmp-agentslist.txt tmp-agents.xml agents.txt tmp-agents-config.xml

touch tmp-agentslist.txt tmp-agents.xml agents.txt tmp-agents-config.xml
chmod 777 tmp-agentslist.txt tmp-agents.xml agents.txt tmp-agents-config.xml

tcURL=$3
username=$1
password=$2

# Validate the script's input
if [[ $# -lt 2 ]] ; then
    echo "usage:  {username: Teamcity username} {password: Username's password}"
    exit 1
fi


contents=$(curl -k -s -u $username:$password $tcURL/app/rest/agents)
echo "$contents" > tmp-agents.xml
#vcsCount=$(echo "cat //vcs-roots/@count" | xmllint --shell tmp-vcs-root.xml | grep count | sed 's/[^0-9]*//g')
#echo " $vcsCount "
getAllAgents=$(echo "cat //agent/@id" | xmllint --shell tmp-agents.xml | grep id | cut -d \" -f2)
echo " $getAllAgents ">agents.txt
echo "Agent_Id,Agent_Name,Agent_Server_IP">>teamcity_agent_detsils.csv
for i in `cat agents.txt`
do
contents1=$(curl -k -s -u $username:$password $tcURL/app/rest/agents/id:$i)
echo "$contents1">tmp-agents-config.xml
agentname=$(echo "cat //agent/@name" | xmllint --shell tmp-agents-config.xml | grep name | cut -d \" -f2)
agentserverip=$(echo "cat //agent/@ip" | xmllint --shell tmp-agents-config.xml | grep ip| cut -d \" -f2)
echo "$i,$agentname,$agentserverip " >>teamcity_agent_detsils.csv
done
rm -rf tmp-agentslist.txt tmp-agents.xml agents.txt tmp-agents-config.xml
