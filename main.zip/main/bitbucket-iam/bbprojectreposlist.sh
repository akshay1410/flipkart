#/bin/sh!
#!/bin/bash
#set -x
#########################################################################################################
#                       Script for bb project and repos                                      #
#                       Author: Akshay kumar                                                            #
#                       Date: Aug  28, 2020                                                            #
#########################################################################################################

## files creation and initialisation

>bbprojectkey.txt
>bbprojrepogroup.csv
#Passed arguments handling and assiging them to variables
bitburl=$3
username=$1
password=$2


# Validate the script's Arguments
if [[ $# -lt 3 ]] ; then
    echo "usage:  {username: Bitbucket username} {password: Username's password} {BitbucketURL:} "
    exit 1
fi


#Feching project key

curl -s -k -u $username:$password $bitburl/rest/api/1.0/projects?limit=1000 | python -mjson.tool | grep key | awk -F: '{print $2}' | sed s'/"//g' | sed s'/,//g' | sed s'/ //g' >>bbprojectkey.txt


curl -s -k -u $username:$password $bitburl/rest/api/1.0/projects?start=1000"&&"limit=1000 | python -mjson.tool | grep key | awk -F: '{print $2}' | sed s'/"//g' | sed s'/,//g' | sed s'/ //g' >>bbprojectkey.txt



#repo slug
echo "Projectkey","Repo-slug">>bbprojrepolist.csv


for key in `cat bbprojectkey.txt`
do
for slug in `curl -s -k -u $username:$password $bitburl/rest/api/1.0/projects/$key/repos | python -mjson.tool | grep slug | awk -F: '{ print $2}' | sed 's/"//g' | sed 's/,//g'`
do
echo "$key","$slug">>bbprojrepolist.csv
done
done

